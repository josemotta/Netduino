/* ----------------------------------------------------------------------------
 *         ATMEL Microcontroller Software Support 
 * ----------------------------------------------------------------------------
 * Copyright (c) 2008, Atmel Corporation
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ----------------------------------------------------------------------------
 */
//------------------------------------------------------------------------------
/// \unit
///
/// !Purpose
///
/// Interface for configuration the Embedded Flash Controller (EFC) peripheral.
///
/// !Usage
///
/// -# Initialize system master clock of the EFC with EFC_SetMasterClock().
/// -# Enable/disable interrupt sources using EFC_EnableIt() and EFC_DisableIt().
/// -# Enables or disable the "Erase before programming" feature using 
///    EFC_SetEraseBeforeProgramming().
/// -# Translates the given address into which EFC, page and offset values for 
///    difference density %flash memory using EFC_TranslateAddress().
/// -# Computes the address of a %flash access given the EFC, page and offset 
///    for difference density %flash memory using EFC_ComputeAddress().
/// -# Start the executing command with EFC_StartCommand()
/// -# Retrieve the current status of the EFC using EFC_GetStatus().
///
//------------------------------------------------------------------------------
#ifndef EFC_H
#define EFC_H

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------

#include <board.h>

#if !defined (CHIP_FLASH_EFC)
#error efc not supported
#endif

//------------------------------------------------------------------------------
//         Constants
//------------------------------------------------------------------------------


// Missing FRDY bit for SAM7A3
#if defined(at91sam7a3)
    #define AT91C_MC_FRDY       (AT91C_MC_EOP | AT91C_MC_EOL)
#endif

// No security bit on SAM7A3
#if defined(at91sam7a3)
    #define EFC_NO_SECURITY_BIT
#endif

//------------------------------------------------------------------------------
//         Types
//------------------------------------------------------------------------------

// For chips which do not define AT91S_EFC
#if !defined(AT91C_BASE_EFC) && !defined(AT91C_BASE_EFC0)
typedef struct _AT91S_EFC {

    AT91_REG EFC_FMR;
    AT91_REG EFC_FCR;
    AT91_REG EFC_FSR;

} AT91S_EFC, *AT91PS_EFC;
	#define AT91C_BASE_EFC       (AT91_CAST(AT91PS_EFC)	0xFFFFFF60) 
#endif	

//------------------------------------------------------------------------------
//         Functions
//------------------------------------------------------------------------------

extern void EFC_SetMasterClock(unsigned int mck);

extern void EFC_EnableIt(AT91S_EFC *pEfc, unsigned int sources);

extern void EFC_DisableIt(AT91S_EFC *pEfc, unsigned int sources);

extern void EFC_SetEraseBeforeProgramming(AT91S_EFC *pEfc, unsigned char enable);

extern void EFC_TranslateAddress(
    AT91S_EFC **ppEfc,
    unsigned int address,
    unsigned short *pPage,
    unsigned short *pOffset);

extern void EFC_ComputeAddress(
    AT91S_EFC *pEfc,
    unsigned short page,
    unsigned short offset,
    unsigned int *pAddress);

extern void EFC_StartCommand(
    AT91S_EFC *pEfc,
    unsigned char command,
    unsigned short argument);

extern unsigned char EFC_PerformCommand(
    AT91S_EFC *pEfc,
    unsigned char command,
    unsigned short argument);

extern unsigned int EFC_GetStatus(AT91S_EFC *pEfc);

#endif //#ifndef EFC_H

