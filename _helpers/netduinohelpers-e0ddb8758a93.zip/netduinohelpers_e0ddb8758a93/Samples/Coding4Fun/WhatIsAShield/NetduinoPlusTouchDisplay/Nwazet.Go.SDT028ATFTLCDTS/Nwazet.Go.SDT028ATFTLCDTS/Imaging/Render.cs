namespace Nwazet.Go.Imaging {
    public enum Render {
        All,
        Dirty
    }
}