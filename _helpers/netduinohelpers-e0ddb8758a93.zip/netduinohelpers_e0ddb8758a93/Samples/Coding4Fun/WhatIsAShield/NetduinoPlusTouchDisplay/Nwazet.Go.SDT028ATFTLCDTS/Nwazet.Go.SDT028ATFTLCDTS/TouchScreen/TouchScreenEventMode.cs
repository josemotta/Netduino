namespace Nwazet.Go.Display.TouchScreen {
    public enum TouchScreenEventMode {
        Blocking,
        NonBlocking
    }
}
