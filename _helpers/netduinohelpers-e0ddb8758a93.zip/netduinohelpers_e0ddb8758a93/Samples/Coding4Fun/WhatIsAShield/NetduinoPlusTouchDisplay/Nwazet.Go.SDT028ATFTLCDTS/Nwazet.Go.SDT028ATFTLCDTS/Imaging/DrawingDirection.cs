namespace Nwazet.Go.Imaging {
    public enum DrawingDirection {
        Left,
        Right,
        Up,
        Down
    }
}