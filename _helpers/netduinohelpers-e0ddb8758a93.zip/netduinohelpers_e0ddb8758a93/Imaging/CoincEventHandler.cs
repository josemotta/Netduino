namespace netduino.helpers.Imaging {
    public delegate bool CoincEventHandler(object sender, PlayerMissile missile1, PlayerMissile missile2);
}
