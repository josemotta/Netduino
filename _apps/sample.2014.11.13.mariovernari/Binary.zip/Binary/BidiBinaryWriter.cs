﻿using System;
using System.IO;
using System.Reflection;

/*
 * Copyright 2012, 2013, 2014 by Mario Vernari, Cet Electronics
 * Part of "Cet Open Toolbox" (http://cetdevelop.codeplex.com/)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Based on the original sources by Microsoft Corporation:
 * http://referencesource.microsoft.com/#mscorlib/system/io/binarywriter.cs
 * 
 * License:
 * http://referencesource.microsoft.com/license.html
 **/
namespace Cet.IO
{
    public class BidiBinaryWriter
        : IDisposable
    {
        /// <summary>Specifies a <see cref="T:System.IO.BinaryWriter" /> with no backing store.</summary>
        /// <filterpriority>1</filterpriority>
        public static readonly BidiBinaryWriter Null = new BidiBinaryWriter();


        static BidiBinaryWriter()
        {
            _decimalGetBytes = typeof(Decimal)
                .GetMethod("GetBytes", BindingFlags.NonPublic);
        }


        /// <summary>Holds the underlying stream.</summary>
        protected Stream OutStream;
        private byte[] _buffer;
        private bool _leaveOpen;
        private static MethodInfo _decimalGetBytes;


        /// <summary>Gets the underlying stream of the <see cref="T:System.IO.BinaryWriter" />.</summary>
        /// <returns>The underlying stream associated with the BinaryWriter.</returns>
        /// <filterpriority>1</filterpriority>
        public virtual Stream BaseStream
        {
            get
            {
                this.Flush();
                return this.OutStream;
            }
        }


        /// <summary>Initializes a new instance of the <see cref="T:System.IO.BinaryWriter" /> class that writes to a stream.</summary>
        protected BidiBinaryWriter()
        {
            this.OutStream = Stream.Null;
            this._buffer = new byte[16];
        }


        /// <summary>Initializes a new instance of the <see cref="T:System.IO.BinaryWriter" /> class based on the supplied stream and a specific character encoding.</summary>
        /// <param name="output">The supplied stream. </param>
        /// <param name="encoding">The character encoding. </param>
        /// <exception cref="T:System.ArgumentException">The stream does not support writing, or the stream is already closed. </exception>
        /// <exception cref="T:System.ArgumentNullException">
        ///   <paramref name="output" /> or <paramref name="encoding" /> is null. </exception>
        public BidiBinaryWriter(Stream output)
            : this(output, false)
        {
        }


        public BidiBinaryWriter(Stream output, bool leaveOpen)
        {
            if (output == null)
            {
                throw new ArgumentNullException("output");
            }
            if (!output.CanWrite)
            {
                throw new ArgumentException("Cannot write on the stream.");
            }
            this.OutStream = output;
            this._buffer = new byte[16];
            this._leaveOpen = leaveOpen;
        }


        /// <summary>Closes the current <see cref="T:System.IO.BinaryWriter" /> and the underlying stream.</summary>
        /// <filterpriority>1</filterpriority>
        public virtual void Close()
        {
            this.Dispose(true);
        }


        /// <summary>Releases the unmanaged resources used by the <see cref="T:System.IO.BinaryWriter" /> and optionally releases the managed resources.</summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources. </param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (this._leaveOpen)
                {
                    this.OutStream.Flush();
                    return;
                }
                this.OutStream.Close();
            }
        }


        /// <summary>Releases all resources used by the current instance of the <see cref="T:System.IO.BinaryWriter" /> class.</summary>
        public void Dispose()
        {
            this.Dispose(true);
        }


        /// <summary>Clears all buffers for the current writer and causes any buffered data to be written to the underlying device.</summary>
        /// <filterpriority>1</filterpriority>
        public virtual void Flush()
        {
            this.OutStream.Flush();
        }


        /// <summary>Sets the position within the current stream.</summary>
        /// <returns>The position with the current stream.</returns>
        /// <param name="offset">A byte offset relative to <paramref name="origin" />. </param>
        /// <param name="origin">A field of <see cref="T:System.IO.SeekOrigin" /> indicating the reference point from which the new position is to be obtained. </param>
        /// <exception cref="T:System.IO.IOException">The file pointer was moved to an invalid location. </exception>
        /// <exception cref="T:System.ArgumentException">The <see cref="T:System.IO.SeekOrigin" /> value is invalid. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual long Seek(int offset, SeekOrigin origin)
        {
            return this.OutStream.Seek((long)offset, origin);
        }


        /// <summary>Writes a one-byte Boolean value to the current stream, with 0 representing false and 1 representing true.</summary>
        /// <param name="value">The Boolean value to write (0 or 1). </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void Write(bool value)
        {
            this._buffer[0] = (byte)(value ? 1 : 0);
            this.OutStream.Write(this._buffer, 0, 1);
        }


        /// <summary>Writes an unsigned byte to the current stream and advances the stream position by one byte.</summary>
        /// <param name="value">The unsigned byte to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void Write(byte value)
        {
            this.OutStream.WriteByte(value);
        }


        /// <summary>Writes a signed byte to the current stream and advances the stream position by one byte.</summary>
        /// <param name="value">The signed byte to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        [CLSCompliant(false)]
        public virtual void Write(sbyte value)
        {
            this.OutStream.WriteByte((byte)value);
        }


        /// <summary>Writes a byte array to the underlying stream.</summary>
        /// <param name="buffer">A byte array containing the data to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.ArgumentNullException">
        ///   <paramref name="buffer" /> is null. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void Write(byte[] buffer)
        {
            if (buffer == null)
            {
                throw new ArgumentNullException("buffer");
            }
            this.OutStream.Write(buffer, 0, buffer.Length);
        }


        /// <summary>Writes a region of a byte array to the current stream.</summary>
        /// <param name="buffer">A byte array containing the data to write. </param>
        /// <param name="index">The starting point in <paramref name="buffer" /> at which to begin writing. </param>
        /// <param name="count">The number of bytes to write. </param>
        /// <exception cref="T:System.ArgumentException">The buffer length minus <paramref name="index" /> is less than <paramref name="count" />. </exception>
        /// <exception cref="T:System.ArgumentNullException">
        ///   <paramref name="buffer" /> is null. </exception>
        /// <exception cref="T:System.ArgumentOutOfRangeException">
        ///   <paramref name="index" /> or <paramref name="count" /> is negative. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void Write(byte[] buffer, int index, int count)
        {
            this.OutStream.Write(buffer, index, count);
        }


        /// <summary>Writes an eight-byte floating-point value (Little-endian) to the current stream and advances the stream position by eight bytes.</summary>
        /// <param name="value">The eight-byte floating-point value to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public unsafe virtual void WriteDoubleLE(double value)
        {
            ulong num = *(ulong*)(&value);

            if (BitConverter.IsLittleEndian)
            {
                this._buffer[0] = (byte)num;
                this._buffer[1] = (byte)(num >> 8);
                this._buffer[2] = (byte)(num >> 16);
                this._buffer[3] = (byte)(num >> 24);
                this._buffer[4] = (byte)(num >> 32);
                this._buffer[5] = (byte)(num >> 40);
                this._buffer[6] = (byte)(num >> 48);
                this._buffer[7] = (byte)(num >> 56);
            }
            else
            {
                this._buffer[7] = (byte)num;
                this._buffer[6] = (byte)(num >> 8);
                this._buffer[5] = (byte)(num >> 16);
                this._buffer[4] = (byte)(num >> 24);
                this._buffer[3] = (byte)(num >> 32);
                this._buffer[2] = (byte)(num >> 40);
                this._buffer[1] = (byte)(num >> 48);
                this._buffer[0] = (byte)(num >> 56);
            }

            this.OutStream.Write(this._buffer, 0, 8);
        }


        /// <summary>Writes an eight-byte floating-point value (Big-endian) to the current stream and advances the stream position by eight bytes.</summary>
        /// <param name="value">The eight-byte floating-point value to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public unsafe virtual void WriteDoubleBE(double value)
        {
            ulong num = *(ulong*)(&value);

            if (BitConverter.IsLittleEndian == false)
            {
                this._buffer[0] = (byte)num;
                this._buffer[1] = (byte)(num >> 8);
                this._buffer[2] = (byte)(num >> 16);
                this._buffer[3] = (byte)(num >> 24);
                this._buffer[4] = (byte)(num >> 32);
                this._buffer[5] = (byte)(num >> 40);
                this._buffer[6] = (byte)(num >> 48);
                this._buffer[7] = (byte)(num >> 56);
            }
            else
            {
                this._buffer[7] = (byte)num;
                this._buffer[6] = (byte)(num >> 8);
                this._buffer[5] = (byte)(num >> 16);
                this._buffer[4] = (byte)(num >> 24);
                this._buffer[3] = (byte)(num >> 32);
                this._buffer[2] = (byte)(num >> 40);
                this._buffer[1] = (byte)(num >> 48);
                this._buffer[0] = (byte)(num >> 56);
            }

            this.OutStream.Write(this._buffer, 0, 8);
        }


        /// <summary>Writes a decimal value (Little-endian) to the current stream and advances the stream position by sixteen bytes.</summary>
        /// <param name="value">The decimal value to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteDecimalLE(decimal value)
        {
            //decimal.GetBytes(value, this._buffer);
            _decimalGetBytes.Invoke(
                null,
                new object[] { value, this._buffer }
                );

            if (BitConverter.IsLittleEndian == false)
            {
                //mirror the byte buffer
                for (int i = 7; i >= 0; i--)
                {
                    BidiBinaryReader.SwapBytes(
                        ref this._buffer[i],
                        ref this._buffer[15 - i]
                        );
                }
            }

            this.OutStream.Write(this._buffer, 0, 16);
        }


        /// <summary>Writes a decimal value (Big-endian) to the current stream and advances the stream position by sixteen bytes.</summary>
        /// <param name="value">The decimal value to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteDecimalBE(decimal value)
        {
            //decimal.GetBytes(value, this._buffer);
            _decimalGetBytes.Invoke(
                null,
                new object[] { value, this._buffer }
                );

            if (BitConverter.IsLittleEndian)
            {
                //mirror the byte buffer
                for (int i = 7; i >= 0; i--)
                {
                    BidiBinaryReader.SwapBytes(
                        ref this._buffer[i],
                        ref this._buffer[15 - i]
                        );
                }
            }

            this.OutStream.Write(this._buffer, 0, 16);
        }


        /// <summary>Writes a two-byte signed integer (Little-endian) to the current stream and advances the stream position by two bytes.</summary>
        /// <param name="value">The two-byte signed integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteInt16LE(short value)
        {
            this._buffer[0] = (byte)value;
            this._buffer[1] = (byte)(value >> 8);
            this.OutStream.Write(this._buffer, 0, 2);
        }


        /// <summary>Writes a two-byte signed integer (Big-endian) to the current stream and advances the stream position by two bytes.</summary>
        /// <param name="value">The two-byte signed integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteInt16BE(short value)
        {
            this._buffer[1] = (byte)value;
            this._buffer[0] = (byte)(value >> 8);
            this.OutStream.Write(this._buffer, 0, 2);
        }


        /// <summary>Writes a two-byte unsigned integer (Little-endian) to the current stream and advances the stream position by two bytes.</summary>
        /// <param name="value">The two-byte unsigned integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        [CLSCompliant(false)]
        public virtual void WriteUInt16LE(ushort value)
        {
            this._buffer[0] = (byte)value;
            this._buffer[1] = (byte)(value >> 8);
            this.OutStream.Write(this._buffer, 0, 2);
        }


        /// <summary>Writes a two-byte unsigned integer (Big-endian) to the current stream and advances the stream position by two bytes.</summary>
        /// <param name="value">The two-byte unsigned integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        [CLSCompliant(false)]
        public virtual void WriteUInt16BE(ushort value)
        {
            this._buffer[1] = (byte)value;
            this._buffer[0] = (byte)(value >> 8);
            this.OutStream.Write(this._buffer, 0, 2);
        }


        /// <summary>Writes a four-byte signed integer (Little-endian) to the current stream and advances the stream position by four bytes.</summary>
        /// <param name="value">The four-byte signed integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteInt32LE(int value)
        {
            this._buffer[0] = (byte)value;
            this._buffer[1] = (byte)(value >> 8);
            this._buffer[2] = (byte)(value >> 16);
            this._buffer[3] = (byte)(value >> 24);
            this.OutStream.Write(this._buffer, 0, 4);
        }


        /// <summary>Writes a four-byte signed integer (Big-endian) to the current stream and advances the stream position by four bytes.</summary>
        /// <param name="value">The four-byte signed integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteInt32BE(int value)
        {
            this._buffer[3] = (byte)value;
            this._buffer[2] = (byte)(value >> 8);
            this._buffer[1] = (byte)(value >> 16);
            this._buffer[0] = (byte)(value >> 24);
            this.OutStream.Write(this._buffer, 0, 4);
        }


        /// <summary>Writes a four-byte unsigned integer (Little-endian) to the current stream and advances the stream position by four bytes.</summary>
        /// <param name="value">The four-byte unsigned integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        [CLSCompliant(false)]
        public virtual void WriteUInt32LE(uint value)
        {
            this._buffer[0] = (byte)value;
            this._buffer[1] = (byte)(value >> 8);
            this._buffer[2] = (byte)(value >> 16);
            this._buffer[3] = (byte)(value >> 24);
            this.OutStream.Write(this._buffer, 0, 4);
        }


        /// <summary>Writes a four-byte unsigned integer (Big-endian) to the current stream and advances the stream position by four bytes.</summary>
        /// <param name="value">The four-byte unsigned integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        [CLSCompliant(false)]
        public virtual void WriteUInt32BE(uint value)
        {
            this._buffer[3] = (byte)value;
            this._buffer[2] = (byte)(value >> 8);
            this._buffer[1] = (byte)(value >> 16);
            this._buffer[0] = (byte)(value >> 24);
            this.OutStream.Write(this._buffer, 0, 4);
        }


        /// <summary>Writes an eight-byte signed integer (Little-endian) to the current stream and advances the stream position by eight bytes.</summary>
        /// <param name="value">The eight-byte signed integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteInt64LE(long value)
        {
            this._buffer[0] = (byte)value;
            this._buffer[1] = (byte)(value >> 8);
            this._buffer[2] = (byte)(value >> 16);
            this._buffer[3] = (byte)(value >> 24);
            this._buffer[4] = (byte)(value >> 32);
            this._buffer[5] = (byte)(value >> 40);
            this._buffer[6] = (byte)(value >> 48);
            this._buffer[7] = (byte)(value >> 56);
            this.OutStream.Write(this._buffer, 0, 8);
        }


        /// <summary>Writes an eight-byte signed integer (Big-endian) to the current stream and advances the stream position by eight bytes.</summary>
        /// <param name="value">The eight-byte signed integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public virtual void WriteInt64BE(long value)
        {
            this._buffer[7] = (byte)value;
            this._buffer[6] = (byte)(value >> 8);
            this._buffer[5] = (byte)(value >> 16);
            this._buffer[4] = (byte)(value >> 24);
            this._buffer[3] = (byte)(value >> 32);
            this._buffer[2] = (byte)(value >> 40);
            this._buffer[1] = (byte)(value >> 48);
            this._buffer[0] = (byte)(value >> 56);
            this.OutStream.Write(this._buffer, 0, 8);
        }


        /// <summary>Writes an eight-byte unsigned integer (Little-endian) to the current stream and advances the stream position by eight bytes.</summary>
        /// <param name="value">The eight-byte unsigned integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        [CLSCompliant(false)]
        public virtual void WriteUInt64LE(ulong value)
        {
            this._buffer[0] = (byte)value;
            this._buffer[1] = (byte)(value >> 8);
            this._buffer[2] = (byte)(value >> 16);
            this._buffer[3] = (byte)(value >> 24);
            this._buffer[4] = (byte)(value >> 32);
            this._buffer[5] = (byte)(value >> 40);
            this._buffer[6] = (byte)(value >> 48);
            this._buffer[7] = (byte)(value >> 56);
            this.OutStream.Write(this._buffer, 0, 8);
        }


        /// <summary>Writes an eight-byte unsigned integer (Big-endian) to the current stream and advances the stream position by eight bytes.</summary>
        /// <param name="value">The eight-byte unsigned integer to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        [CLSCompliant(false)]
        public virtual void WriteUInt64BE(ulong value)
        {
            this._buffer[7] = (byte)value;
            this._buffer[6] = (byte)(value >> 8);
            this._buffer[5] = (byte)(value >> 16);
            this._buffer[4] = (byte)(value >> 24);
            this._buffer[3] = (byte)(value >> 32);
            this._buffer[2] = (byte)(value >> 40);
            this._buffer[1] = (byte)(value >> 48);
            this._buffer[0] = (byte)(value >> 56);
            this.OutStream.Write(this._buffer, 0, 8);
        }


        /// <summary>Writes a four-byte floating-point value (Little-endian) to the current stream and advances the stream position by four bytes.</summary>
        /// <param name="value">The four-byte floating-point value to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public unsafe virtual void WriteSingleLE(float value)
        {
            uint num = *(uint*)(&value);

            if (BitConverter.IsLittleEndian)
            {
                this._buffer[0] = (byte)num;
                this._buffer[1] = (byte)(num >> 8);
                this._buffer[2] = (byte)(num >> 16);
                this._buffer[3] = (byte)(num >> 24);
            }
            else
            {
                this._buffer[3] = (byte)num;
                this._buffer[2] = (byte)(num >> 8);
                this._buffer[1] = (byte)(num >> 16);
                this._buffer[0] = (byte)(num >> 24);
            }

            this.OutStream.Write(this._buffer, 0, 4);
        }


        /// <summary>Writes a four-byte floating-point value (Big-endian) to the current stream and advances the stream position by four bytes.</summary>
        /// <param name="value">The four-byte floating-point value to write. </param>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>1</filterpriority>
        public unsafe virtual void WriteSingleBE(float value)
        {
            uint num = *(uint*)(&value);

            if (BitConverter.IsLittleEndian == false)
            {
                this._buffer[0] = (byte)num;
                this._buffer[1] = (byte)(num >> 8);
                this._buffer[2] = (byte)(num >> 16);
                this._buffer[3] = (byte)(num >> 24);
            }
            else
            {
                this._buffer[3] = (byte)num;
                this._buffer[2] = (byte)(num >> 8);
                this._buffer[1] = (byte)(num >> 16);
                this._buffer[0] = (byte)(num >> 24);
            }

            this.OutStream.Write(this._buffer, 0, 4);
        }

    }
}
