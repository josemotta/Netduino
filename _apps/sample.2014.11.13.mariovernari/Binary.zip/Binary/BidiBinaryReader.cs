﻿using System;
using System.IO;
using System.Reflection;

/*
 * Copyright 2012, 2013, 2014 by Mario Vernari, Cet Electronics
 * Part of "Cet Open Toolbox" (http://cetdevelop.codeplex.com/)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Based on the original sources by Microsoft Corporation:
 * http://referencesource.microsoft.com/#mscorlib/system/io/binaryreader.cs
 * 
 * License:
 * http://referencesource.microsoft.com/license.html
 **/
namespace Cet.IO
{
    public class BidiBinaryReader
        : IDisposable
    {
        static BidiBinaryReader()
        {
            _decimalToDecimal = typeof(Decimal)
                .GetMethod("ToDecimal", BindingFlags.NonPublic);
        }


        private Stream m_stream;
        private byte[] m_buffer;
        private bool m_leaveOpen;
        private static MethodInfo _decimalToDecimal;


        /// <summary>Exposes access to the underlying stream of the <see cref="T:System.IO.BinaryReader" />.</summary>
        /// <returns>The underlying stream associated with the BinaryReader.</returns>
        /// <filterpriority>2</filterpriority>
        public virtual Stream BaseStream
        {
            get { return this.m_stream; }
        }


        /// <summary>Initializes a new instance of the <see cref="T:System.IO.BinaryReader" /> class based on the supplied stream and using <see cref="T:System.Text.UTF8Encoding" />.</summary>
        /// <param name="input">A stream. </param>
        /// <exception cref="T:System.ArgumentException">The stream does not support reading, the stream is null, or the stream is already closed. </exception>
        public BidiBinaryReader(Stream input)
            : this(input, false)
        {
        }


        public BidiBinaryReader(Stream input, bool leaveOpen)
        {
            if (input == null)
            {
                throw new ArgumentNullException("input");
            }
            if (!input.CanRead)
            {
                throw new ArgumentException("Cannot write on the stream.");
            }

            this.m_stream = input;
            this.m_buffer = new byte[16];
            this.m_leaveOpen = leaveOpen;
        }


        /// <summary>Closes the current reader and the underlying stream.</summary>
        /// <filterpriority>2</filterpriority>
        public virtual void Close()
        {
            this.Dispose(true);
        }


        /// <summary>Releases the unmanaged resources used by the <see cref="T:System.IO.BinaryReader" /> class and optionally releases the managed resources.</summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources. </param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Stream stream = this.m_stream;
                this.m_stream = null;
                if (stream != null && !this.m_leaveOpen)
                {
                    stream.Close();
                }
            }
            this.m_stream = null;
            this.m_buffer = null;
        }


        /// <summary>Releases all resources used by the current instance of the <see cref="T:System.IO.BinaryReader" /> class.</summary>
        public void Dispose()
        {
            this.Dispose(true);
        }


        /// <summary>Reads a Boolean value from the current stream and advances the current position of the stream by one byte.</summary>
        /// <returns>true if the byte is nonzero; otherwise, false.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual bool ReadBoolean()
        {
            this.FillBuffer(1);
            return this.m_buffer[0] != 0;
        }


        /// <summary>Reads the next byte from the current stream and advances the current position of the stream by one byte.</summary>
        /// <returns>The next byte read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual byte ReadByte()
        {
            if (this.m_stream == null)
            {
                throw new ObjectDisposedException(null);
            }
            int num = this.m_stream.ReadByte();
            if (num == -1)
            {
                throw new EndOfStreamException("Attempt to read past end of the stream.");
            }
            return (byte)num;
        }


        /// <summary>Reads a signed byte from this stream and advances the current position of the stream by one byte.</summary>
        /// <returns>A signed byte read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        [CLSCompliant(false)]
        public virtual sbyte ReadSByte()
        {
            this.FillBuffer(1);
            return (sbyte)this.m_buffer[0];
        }


        /// <summary>Reads a 2-byte signed integer (Little-endian) from the current stream and advances the current position of the stream by two bytes.</summary>
        /// <returns>A 2-byte signed integer read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual short ReadInt16LE()
        {
            this.FillBuffer(2);
            return (short)(
                (int)this.m_buffer[0] |
                (int)this.m_buffer[1] << 8
                );
        }


        /// <summary>Reads a 2-byte signed integer (Big-endian) from the current stream and advances the current position of the stream by two bytes.</summary>
        /// <returns>A 2-byte signed integer read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual short ReadInt16BE()
        {
            this.FillBuffer(2);
            return (short)(
                (int)this.m_buffer[1] |
                (int)this.m_buffer[0] << 8
                );
        }


        /// <summary>Reads a 2-byte unsigned integer (Little-endian) from the current stream using little-endian encoding and advances the position of the stream by two bytes.</summary>
        /// <returns>A 2-byte unsigned integer read from this stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        [CLSCompliant(false)]
        public virtual ushort ReadUInt16LE()
        {
            this.FillBuffer(2);
            return (ushort)(
                (int)this.m_buffer[0] |
                (int)this.m_buffer[1] << 8
                );
        }


        /// <summary>Reads a 2-byte unsigned integer (Big-endian) from the current stream using little-endian encoding and advances the position of the stream by two bytes.</summary>
        /// <returns>A 2-byte unsigned integer read from this stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        [CLSCompliant(false)]
        public virtual ushort ReadUInt16BE()
        {
            this.FillBuffer(2);
            return (ushort)(
                (int)this.m_buffer[1] |
                (int)this.m_buffer[0] << 8
                );
        }


        /// <summary>Reads a 4-byte signed integer (Little-endian) from the current stream and advances the current position of the stream by four bytes.</summary>
        /// <returns>A 4-byte signed integer read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual int ReadInt32LE()
        {
            this.FillBuffer(4);
            return
                (int)this.m_buffer[0] |
                (int)this.m_buffer[1] << 8 |
                (int)this.m_buffer[2] << 16 |
                (int)this.m_buffer[3] << 24;
        }


        /// <summary>Reads a 4-byte signed integer (Big-endian) from the current stream and advances the current position of the stream by four bytes.</summary>
        /// <returns>A 4-byte signed integer read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual int ReadInt32BE()
        {
            this.FillBuffer(4);
            return
                (int)this.m_buffer[3] |
                (int)this.m_buffer[2] << 8 |
                (int)this.m_buffer[1] << 16 |
                (int)this.m_buffer[0] << 24;
        }


        /// <summary>Reads a 4-byte unsigned integer (Little-endian) from the current stream and advances the position of the stream by four bytes.</summary>
        /// <returns>A 4-byte unsigned integer read from this stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        [CLSCompliant(false)]
        public virtual uint ReadUInt32LE()
        {
            this.FillBuffer(4);
            return (uint)(
                (int)this.m_buffer[0] |
                (int)this.m_buffer[1] << 8 |
                (int)this.m_buffer[2] << 16 |
                (int)this.m_buffer[3] << 24
                );
        }


        /// <summary>Reads a 4-byte unsigned integer (Big-endian) from the current stream and advances the position of the stream by four bytes.</summary>
        /// <returns>A 4-byte unsigned integer read from this stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        [CLSCompliant(false)]
        public virtual uint ReadUInt32BE()
        {
            this.FillBuffer(4);
            return (uint)(
                (int)this.m_buffer[3] |
                (int)this.m_buffer[2] << 8 |
                (int)this.m_buffer[1] << 16 |
                (int)this.m_buffer[0] << 24
                );
        }


        /// <summary>Reads an 8-byte signed integer (Little-endian) from the current stream and advances the current position of the stream by eight bytes.</summary>
        /// <returns>An 8-byte signed integer read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual long ReadInt64LE()
        {
            this.FillBuffer(8);
            uint num = (uint)(
                (int)this.m_buffer[0] |
                (int)this.m_buffer[1] << 8 |
                (int)this.m_buffer[2] << 16 |
                (int)this.m_buffer[3] << 24
                );

            uint num2 = (uint)(
                (int)this.m_buffer[4] |
                (int)this.m_buffer[5] << 8 |
                (int)this.m_buffer[6] << 16 |
                (int)this.m_buffer[7] << 24
                );

            return (long)(
                (ulong)num2 << 32 |
                (ulong)num
                );
        }


        /// <summary>Reads an 8-byte signed integer (Big-endian) from the current stream and advances the current position of the stream by eight bytes.</summary>
        /// <returns>An 8-byte signed integer read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual long ReadInt64BE()
        {
            this.FillBuffer(8);
            uint num = (uint)(
                (int)this.m_buffer[7] |
                (int)this.m_buffer[6] << 8 |
                (int)this.m_buffer[5] << 16 |
                (int)this.m_buffer[4] << 24
                );

            uint num2 = (uint)(
                (int)this.m_buffer[3] |
                (int)this.m_buffer[2] << 8 |
                (int)this.m_buffer[1] << 16 |
                (int)this.m_buffer[0] << 24
                );

            return (long)(
                (ulong)num2 << 32 |
                (ulong)num
                );
        }


        /// <summary>Reads an 8-byte unsigned integer (Little-endian) from the current stream and advances the position of the stream by eight bytes.</summary>
        /// <returns>An 8-byte unsigned integer read from this stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>2</filterpriority>
        [CLSCompliant(false)]
        public virtual ulong ReadUInt64LE()
        {
            this.FillBuffer(8);
            uint num = (uint)(
                (int)this.m_buffer[0] |
                (int)this.m_buffer[1] << 8 |
                (int)this.m_buffer[2] << 16 |
                (int)this.m_buffer[3] << 24
                );

            uint num2 = (uint)(
                (int)this.m_buffer[4] |
                (int)this.m_buffer[5] << 8 |
                (int)this.m_buffer[6] << 16 |
                (int)this.m_buffer[7] << 24
                );

            return
                (ulong)num2 << 32 |
                (ulong)num;
        }


        /// <summary>Reads an 8-byte unsigned integer (Big-endian) from the current stream and advances the position of the stream by eight bytes.</summary>
        /// <returns>An 8-byte unsigned integer read from this stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <filterpriority>2</filterpriority>
        [CLSCompliant(false)]
        public virtual ulong ReadUInt64BE()
        {
            this.FillBuffer(8);
            uint num = (uint)(
                (int)this.m_buffer[7] |
                (int)this.m_buffer[6] << 8 |
                (int)this.m_buffer[5] << 16 |
                (int)this.m_buffer[4] << 24
                );

            uint num2 = (uint)(
                (int)this.m_buffer[3] |
                (int)this.m_buffer[2] << 8 |
                (int)this.m_buffer[1] << 16 |
                (int)this.m_buffer[0] << 24
                );

            return
                (ulong)num2 << 32 |
                (ulong)num;
        }


        /// <summary>Reads a 4-byte floating point value (Little-endian) from the current stream and advances the current position of the stream by four bytes.</summary>
        /// <returns>A 4-byte floating point value read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public unsafe virtual float ReadSingleLE()
        {
            this.FillBuffer(4);

            uint num;
            if (BitConverter.IsLittleEndian)
            {
                num = (uint)(
                    (int)this.m_buffer[0] |
                    (int)this.m_buffer[1] << 8 |
                    (int)this.m_buffer[2] << 16 |
                    (int)this.m_buffer[3] << 24
                    );
            }
            else
            {
                num = (uint)(
                    (int)this.m_buffer[3] |
                    (int)this.m_buffer[2] << 8 |
                    (int)this.m_buffer[1] << 16 |
                    (int)this.m_buffer[0] << 24
                    );
            }

            return *(float*)(&num);
        }


        /// <summary>Reads a 4-byte floating point value (Big-endian) from the current stream and advances the current position of the stream by four bytes.</summary>
        /// <returns>A 4-byte floating point value read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public unsafe virtual float ReadSingleBE()
        {
            this.FillBuffer(4);

            uint num;
            if (BitConverter.IsLittleEndian)
            {
                num = (uint)(
                    (int)this.m_buffer[3] |
                    (int)this.m_buffer[2] << 8 |
                    (int)this.m_buffer[1] << 16 |
                    (int)this.m_buffer[0] << 24
                    );
            }
            else
            {
                num = (uint)(
                    (int)this.m_buffer[0] |
                    (int)this.m_buffer[1] << 8 |
                    (int)this.m_buffer[2] << 16 |
                    (int)this.m_buffer[3] << 24
                    );
            }

            return *(float*)(&num);
        }


        /// <summary>Reads an 8-byte floating point value (Little-endian) from the current stream and advances the current position of the stream by eight bytes.</summary>
        /// <returns>An 8-byte floating point value read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public unsafe virtual double ReadDoubleLE()
        {
            this.FillBuffer(8);

            ulong num3;
            if (BitConverter.IsLittleEndian)
            {
                uint num = (uint)(
                    (int)this.m_buffer[0] |
                    (int)this.m_buffer[1] << 8 |
                    (int)this.m_buffer[2] << 16 |
                    (int)this.m_buffer[3] << 24
                    );

                uint num2 = (uint)(
                    (int)this.m_buffer[4] |
                    (int)this.m_buffer[5] << 8 |
                    (int)this.m_buffer[6] << 16 |
                    (int)this.m_buffer[7] << 24
                    );

                num3 =
                    (ulong)num2 << 32 |
                    (ulong)num;
            }
            else
            {
                uint num = (uint)(
                    (int)this.m_buffer[7] |
                    (int)this.m_buffer[6] << 8 |
                    (int)this.m_buffer[5] << 16 |
                    (int)this.m_buffer[4] << 24
                    );

                uint num2 = (uint)(
                    (int)this.m_buffer[3] |
                    (int)this.m_buffer[2] << 8 |
                    (int)this.m_buffer[1] << 16 |
                    (int)this.m_buffer[0] << 24
                    );

                num3 =
                    (ulong)num2 << 32 |
                    (ulong)num;
            }

            return *(double*)(&num3);
        }


        /// <summary>Reads an 8-byte floating point value (Big-endian) from the current stream and advances the current position of the stream by eight bytes.</summary>
        /// <returns>An 8-byte floating point value read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public unsafe virtual double ReadDoubleBE()
        {
            this.FillBuffer(8);

            ulong num3;
            if (BitConverter.IsLittleEndian)
            {
                uint num = (uint)(
                    (int)this.m_buffer[7] |
                    (int)this.m_buffer[6] << 8 |
                    (int)this.m_buffer[5] << 16 |
                    (int)this.m_buffer[4] << 24
                    );

                uint num2 = (uint)(
                    (int)this.m_buffer[3] |
                    (int)this.m_buffer[2] << 8 |
                    (int)this.m_buffer[1] << 16 |
                    (int)this.m_buffer[0] << 24
                    );

                num3 =
                    (ulong)num2 << 32 |
                    (ulong)num;
            }
            else
            {
                uint num = (uint)(
                    (int)this.m_buffer[0] |
                    (int)this.m_buffer[1] << 8 |
                    (int)this.m_buffer[2] << 16 |
                    (int)this.m_buffer[3] << 24
                    );

                uint num2 = (uint)(
                    (int)this.m_buffer[4] |
                    (int)this.m_buffer[5] << 8 |
                    (int)this.m_buffer[6] << 16 |
                    (int)this.m_buffer[7] << 24
                    );

                num3 =
                    (ulong)num2 << 32 |
                    (ulong)num;
            }

            return *(double*)(&num3);
        }


        /// <summary>Reads a decimal value (Little-endian) from the current stream and advances the current position of the stream by sixteen bytes.</summary>
        /// <returns>A decimal value read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual decimal ReadDecimalLE()
        {
            this.FillBuffer(16, BitConverter.IsLittleEndian == false);

            decimal result;
            try
            {
                //result = decimal.ToDecimal(this.m_buffer);
                result = (decimal)_decimalToDecimal.Invoke(
                    null,
                    new object[] { this.m_buffer }
                    );
            }
            catch (ArgumentException innerException)
            {
                throw new IOException(string.Empty, innerException);
            }
            return result;
        }


        /// <summary>Reads a decimal value (Big-endian) from the current stream and advances the current position of the stream by sixteen bytes.</summary>
        /// <returns>A decimal value read from the current stream.</returns>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual decimal ReadDecimalBE()
        {
            this.FillBuffer(16, BitConverter.IsLittleEndian);

            decimal result;
            try
            {
                //result = decimal.ToDecimal(this.m_buffer);
                result = (decimal)_decimalToDecimal.Invoke(
                    null,
                    new object[] { this.m_buffer }
                    );
            }
            catch (ArgumentException innerException)
            {
                throw new IOException(string.Empty, innerException);
            }
            return result;
        }


        /// <summary>Reads the specified number of bytes from the stream, starting from a specified point in the byte array. </summary>
        /// <returns>The number of bytes read into <paramref name="buffer" />. This might be less than the number of bytes requested if that many bytes are not available, or it might be zero if the end of the stream is reached.</returns>
        /// <param name="buffer">The buffer to read data into. </param>
        /// <param name="index">The starting point in the buffer at which to begin reading into the buffer. </param>
        /// <param name="count">The number of bytes to read. </param>
        /// <exception cref="T:System.ArgumentException">The buffer length minus <paramref name="index" /> is less than <paramref name="count" />. -or-The number of decoded characters to read is greater than <paramref name="count" />. This can happen if a Unicode decoder returns fallback characters or a surrogate pair.</exception>
        /// <exception cref="T:System.ArgumentNullException">
        ///   <paramref name="buffer" /> is null. </exception>
        /// <exception cref="T:System.ArgumentOutOfRangeException">
        ///   <paramref name="index" /> or <paramref name="count" /> is negative. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual int Read(byte[] buffer, int index, int count)
        {
            if (buffer == null)
            {
                throw new ArgumentNullException("buffer");
            }
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index");
            }
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count");
            }
            if (buffer.Length - index < count)
            {
                throw new ArgumentException("Invalid offset.");
            }
            if (this.m_stream == null)
            {
                throw new ObjectDisposedException(null);
            }
            return this.m_stream.Read(buffer, index, count);
        }


        /// <summary>Reads the specified number of bytes from the current stream into a byte array and advances the current position by that number of bytes.</summary>
        /// <returns>A byte array containing data read from the underlying stream. This might be less than the number of bytes requested if the end of the stream is reached.</returns>
        /// <param name="count">The number of bytes to read. </param>
        /// <exception cref="T:System.ArgumentException">The number of decoded characters to read is greater than <paramref name="count" />. This can happen if a Unicode decoder returns fallback characters or a surrogate pair.</exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ObjectDisposedException">The stream is closed. </exception>
        /// <exception cref="T:System.ArgumentOutOfRangeException">
        ///   <paramref name="count" /> is negative. </exception>
        /// <filterpriority>2</filterpriority>
        public virtual byte[] ReadBytes(int count)
        {
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count");
            }
            if (this.m_stream == null)
            {
                throw new ObjectDisposedException(null);
            }
            if (count == 0)
            {
                return new byte[0];
            }
            byte[] array = new byte[count];
            int num = 0;
            do
            {
                int num2 = this.m_stream.Read(array, num, count);
                if (num2 == 0)
                {
                    break;
                }
                num += num2;
                count -= num2;
            }
            while (count > 0);
            if (num != array.Length)
            {
                byte[] array2 = new byte[num];
                Buffer.BlockCopy(array, 0, array2, 0, num);
                array = array2;
            }
            return array;
        }


        /// <summary>Fills the internal buffer with the specified number of bytes read from the stream.</summary>
        /// <param name="numBytes">The number of bytes to be read. </param>
        /// <param name="mirror">Indicate whether to mirror the byte buffer</param>
        /// <exception cref="T:System.IO.EndOfStreamException">The end of the stream is reached before <paramref name="numBytes" /> could be read. </exception>
        /// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
        /// <exception cref="T:System.ArgumentOutOfRangeException">Requested <paramref name="numBytes" /> is larger than the internal buffer size.</exception>
        protected virtual void FillBuffer(
            int numBytes,
            bool mirror = false
            )
        {
            if (this.m_buffer != null && (numBytes < 0 || numBytes > this.m_buffer.Length))
            {
                throw new ArgumentOutOfRangeException("numBytes" );
            }

            int num = 0;
            if (this.m_stream == null)
            {
                throw new ObjectDisposedException(null);
            }

            if (numBytes == 1)
            {
                int num2 = this.m_stream.ReadByte();
                if (num2 == -1)
                {
                    throw new EndOfStreamException("Attempt to read past end of the stream.");
                }
                this.m_buffer[0] = (byte)num2;
                return;
            }

            do
            {
                int num2 = this.m_stream.Read(this.m_buffer, num, numBytes - num);
                if (num2 == 0)
                {
                    throw new EndOfStreamException("Attempt to read past end of the stream.");
                }
                num += num2;
            }
            while (num < numBytes);

            if (numBytes > 1 &&
                mirror)
            {
                //mirror the byte buffer
                int i = (--numBytes) >> 1;
                for (; i >= 0; i--)
                {
                    SwapBytes(
                        ref this.m_buffer[i],
                        ref this.m_buffer[numBytes - i]
                        );
                }
            }
        }


        internal static void SwapBytes(
            ref byte a, 
            ref byte b
            )
        {
            byte x = a;
            a = b;
            b = x;
        }

    }
}
