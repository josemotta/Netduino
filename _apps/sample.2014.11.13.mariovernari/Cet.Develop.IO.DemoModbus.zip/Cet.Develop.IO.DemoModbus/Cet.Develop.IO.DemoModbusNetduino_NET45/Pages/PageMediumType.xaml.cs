﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cet.Develop.IO.DemoModbusNetduino
{
    /// <summary>
    /// Interaction logic for PageMediumType.xaml
    /// </summary>
    public partial class PageMediumType : Page
    {
        public PageMediumType()
        {
            InitializeComponent();
        }


        private void MediumTcpClick(object sender, RoutedEventArgs e)
        {
            HardwareModel.Instance.MediumType = CommMediumType.Tcp;
            this.NavigationService
                .Navigate(new Uri("/Pages/PageNetworkSettings.xaml", UriKind.Relative));
        }


        private void MediumUdpClick(object sender, RoutedEventArgs e)
        {
            HardwareModel.Instance.MediumType = CommMediumType.Udp;
            this.NavigationService
                .Navigate(new Uri("/Pages/PageNetworkSettings.xaml", UriKind.Relative));
        }


        private void MediumRtuClick(object sender, RoutedEventArgs e)
        {
            HardwareModel.Instance.MediumType = CommMediumType.Rtu;
            this.NavigationService
                .Navigate(new Uri("/Pages/PageSerialSettings.xaml", UriKind.Relative));
        }

    }
}
