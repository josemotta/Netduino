﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Cet.Develop.IO.Protocols;


namespace Cet.Develop.IO.TestAcx
{
    public static class PczUsbDriver
    {
        public static CommParams GetDefaultCommParams()
        {
            var prm = new CommParams(
                "9600,N,8,1",
                TimeSpan.FromMilliseconds(500),
                3,
                true,
                TimeSpan.Zero);

            return prm;
        }



        #region ACX blocks definition

        public static readonly AcxBlockRegistrationCollection FirmwareBlock = AcxMemoryDB.Register(
            2,
            new AcxBlockDefinition
            {
                Feature = AcxMemoryBlockFeatures.WriteOnly
                        | AcxMemoryBlockFeatures.VariableLength
                        | AcxMemoryBlockFeatures.AllowGrowing
                        | AcxMemoryBlockFeatures.LockAlways
                        | AcxMemoryBlockFeatures.Obfuscate,
                EraseMode = AcxMemoryBlockErase.DoNotErase,
                Params = new AcxBlockParam[]
                {
                    new AcxBlockParam(AcxCommandCode.CommandLock, null, TimeSpan.FromMilliseconds(3000))
                }
            });



        public static readonly AcxBlockRegistrationCollection TestBlock = AcxMemoryDB.Register(
            2305,
            new AcxBlockDefinition
            {
                Version = new AcxVersion(0, 0, 0),
                NominalLength = 2048,
                Feature = AcxMemoryBlockFeatures.Cached,
                EraseMode = AcxMemoryBlockErase.DoNotErase
            });



        public static readonly AcxBlockRegistrationCollection IdentBlock = AcxMemoryDB.Register(
            36,
            new AcxBlockDefinition
            {
                Version = new AcxVersion(1, 0, 0),
                NominalLength = 12
            });

        #endregion
    }
}
