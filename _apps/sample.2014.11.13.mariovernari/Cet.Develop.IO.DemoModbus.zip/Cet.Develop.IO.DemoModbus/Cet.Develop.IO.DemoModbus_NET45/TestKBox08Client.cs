﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

using Cet.Develop.IO.Protocols;
using Cet.Develop.IO;
using Cet.Develop;
using Cet.Develop.IO.Ports;


namespace ConsoleApplication12
{
    class TestKBox08Client
        : AcxClient
    {
        private TestKBox08Client()
        {
            this.Firmware = new AcxDataBlock(this, 2, 0);
            this.Firmware.PasswordInfo = new AcxPasswordInfo();
            this.Firmware.CommParameters.Add(new AcxCommTimeout(AcxCommandCode.CommandErase, TimeSpan.FromMilliseconds(3000.0)));
            this.Firmware.CommParameters.Add(new AcxCommTimeout(AcxCommandCode.CommandWrite, TimeSpan.FromMilliseconds(1000.0)));
            this.Firmware.CommParameters.Add(new AcxCommTimeout(AcxCommandCode.CommandUnlock, TimeSpan.FromMilliseconds(1000.0)));
            this.Firmware.Progression += new EventHandler<ClientCommandProgressionEventArgs>(Block_Progression);
        }



        public readonly AcxDataBlock Firmware;



        void Block_Progression(object sender, ClientCommandProgressionEventArgs e)
        {
            Console.WriteLine("Progression={0:F1}%", e.Progression);
        }



        public static TestKBox08Client Create (string path)
        {
            var instance = new TestKBox08Client();

            //carica il vdb in chiaro
            var document = XDocument.Load(path);

            //cerca il nodo con id=2 (firmware)
            var elem = document
                .Root
                .Elements()
                .First(_ => (int)_.Attribute("id") == 2);

            //legge la lunghezza
            instance.Firmware.NominalLength = int.Parse(((string)elem.Attribute("bin")).Substring(1));

            //legge lo stream
            var hex = ((string)elem.Attribute("v")).Substring(5);

            var writer = new ByteArrayWriter();
            writer.WriteBytes(ConversionHelper.FromHex(hex));
            instance.Firmware.WriteCache = writer;

            return instance;
        }


        public async static void DoTest()
        {
            using (var port = new PczUsbPort())
            {
                port.PortName = FTDIPort.GetPortNames().First();
                port.Open();
                Console.WriteLine("PortOpen={0}", port.IsOpen);

                var portSetting = new SerialPortParams(
                    "38400,E,8,1",
                    rtsEnable: false);

                ICommClient portClient = port.GetClient(portSetting);

                var client = TestKBox08Client.Create(@"\\s1800\Lib\resources\database\ACX\VDB_KBOX08.xml");
                client.Key = "pippo";
                client.Address = 201;

                //var result = await TaskEx.WhenAll(
                //    clients
                //    .Select(_ => _.ExecuteCommand(portClient).Identify())
                //    );

                //var result = await TaskEx.WhenAll(
                //    clients
                //    .Select(_ => _.ExecuteCommand(portClient).Read(_.Spazio))
                //    );

                var result = await client
                    .ExecuteCommand(portClient)
                    .Identify();

                if (result.Status == CommQueryStatus.Success)
                {
                    result = await client
                        .ExecuteCommand(portClient)
                        .Write(client.Firmware);
                }

                Console.WriteLine(
                    "Owner={0}; {1}",
                    result.Block.Owner.Key,
                    result);
            }
        }

    }
}
