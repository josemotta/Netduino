﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Globalization;


namespace Cet.Develop.Core
{
    public static class DoubleExtensions
    {
        //const value come from sdk\inc\crt\float.h
        public const double DoubleEpsilon = 2.2204460492503131e-016; /* smallest such that 1.0+DBL_EPSILON != 1.0 */


        //const value come from sdk\inc\crt\float.h
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1720:IdentifiersShouldNotContainTypeNames", MessageId = "float")]
        /**************************************************************************
         * Soppresso il warning perche' questo fa parte dei rari casi accettabili
         **************************************************************************/
        public const float FloatMinimum = 1.175494351e-38F; /* Number close to zero, where float.MinValue is -float.MaxValue */


        /// <summary>
        /// Quantizza tramite arrotondamento
        /// </summary>
        /// <param name="value"></param>
        /// <param name="slice"></param>
        /// <returns></returns>
        public static double QuantizeRounding(this Double value, double slice)
        {
            return slice * Math.Round(value / slice);
        }


        /// <summary>
        /// Quantizza tramite troncamento
        /// </summary>
        /// <param name="value"></param>
        /// <param name="slice"></param>
        /// <returns></returns>
        public static double QuantizeTruncating(this Double value, double slice)
        {
            return slice * Math.Floor(value / slice);
        }

        
        /// <summary>
        /// Restituisce la parte frazionaria di un valore reale
        /// </summary>
        /// <param name="value">Il valore reale originale</param>
        /// <returns>La parte frazionaria del valore originale</returns>
        public static Double Fraction(this Double value)
        {
            if (value == 0)
                return value;

            if (value > 0)
            {
                return value - Math.Floor(value);
            }
            else
            {
                return value - Math.Ceiling(value);
            }
        }


        /// <summary>
        /// Converte un valore "double" in una stringa seguento la notazione "ingegneristica".
        /// </summary>
        /// <param name="value">Il valore reale da considerare</param>
        /// <param name="numberOfDigits">Il numero massimo di cifre decimali</param>
        /// <returns>La stringa formattata secondo la notazione</returns>
        /// <example>Ad esempio, fornendo alla funzione il valore 123456 ed un decimale, la stringa risultante sara': 123.4K
        /// Ancora, fornendo 0.000314159 e due decimali si otterra': 314.1μ
        /// </example>
        /// <remarks>La notazione prevede come limiti (in modulo): 1E-21 &lt;= valore &lt; 1E21. Al di fuori di questo intervallo la rappresentazione e' quella di default per i numeri reali "double".</remarks>
        public static string ToString(
            double value, 
            int numberOfDigits)
        {
            //se il valore e' nullo, allora restituisce direttamente la stringa
            if (value == 0)
            {
                return string.Format(
                    CultureInfo.CurrentCulture,
                    "{0:0.0}", 
                    value);
            }

            //prepara i parametri per l'algoritmo di formattazione
            var units = "fpnμm KMGTP";
            var sign = (value < 0) ? "-" : string.Empty;
            var posvalue = Math.Abs(value);
            var exp = Math.Log10(posvalue);
            var symbol = (int)Math.Floor(exp / 3);

            if (symbol == 0)
            {
                //non c'e' bisogno del simbolo, poiche' il valore ricade nell'intervallo: 1 <= valore < 1000
                var delta = numberOfDigits - (int)Math.Floor(exp) + symbol * 3;
                var frac = DoubleExtensions.Fraction(exp);
                var mantissa = Math.Round(Math.Pow(10, numberOfDigits + frac));
                mantissa /= Math.Pow(10, delta);
                return string.Format(
                    CultureInfo.CurrentCulture,
                    "{0}{1}", 
                    sign, 
                    mantissa);
            }
            else if (symbol >= -5 && symbol <= 5)
            {
                //e' previsto uno dei simboli
                var delta = numberOfDigits - (int)Math.Floor(exp) + symbol * 3;
                var frac = DoubleExtensions.Fraction(exp);
                if (frac < 0)
                    frac++;
                var mantissa = Math.Round(Math.Pow(10, numberOfDigits + frac));
                mantissa /= Math.Pow(10, delta);
                return string.Format(
                    CultureInfo.CurrentCulture,
                    "{0}{1} {2}", 
                    sign, 
                    mantissa, 
                    units[5 + symbol]);
            }
            else
            {
                //il valore fornito cade al di fuori dei limiti di formattazione
                return value.ToString(CultureInfo.CurrentCulture);
            }
        }


        /// <summary>
        /// Parsing di una stringa esteso (riconosce anche la notazione "tecnica")
        /// </summary>
        /// <param name="value">La stringa da analizzare</param>
        /// <returns>Il valore double interpretato da questa funzione</returns>
        /// <remarks>
        /// <para>Il metodo vuole estendere il gia' esistente "Parse" della struttura "double", in modo da offrire la possibilita' di riconoscere anche i suffissi "tecnici" (giga, mega, ecc.)</para>
        /// <para>Qualora il formato non venga riconosciuto dal parser nativo, si considera che sia nella forma:</para>
        /// <para>[ws][sign][integral-digits][.[fractional-digits]][[ws]suffix][ws]</para>
        /// <para>Dove:
        /// <list type="table">
        /// <item><term>ws</term><description>uno o piu' spazi</description></item>
        /// <item><term>sign</term><description>il segno piu' od il segno meno</description></item>
        /// <item><term>integral-digits</term><description>una o piu' cifre numeriche costituenti la parte intera</description></item>
        /// <item><term>.</term><description>il separatore decimale (punto o virgola)</description></item>
        /// <item><term>fractional-digits</term><description>una o piu' cifre numeriche costituenti la parte frazionaria</description></item>
        /// <item><term>suffix</term><description>il suffisso che descrive l'esponente (n, G, M, ecc.)</description></item>
        /// </list>
        /// </para>
        /// <para>Per comodita', oltre al simbolo 'µ' (micro) puo' essere usata la 'u' minuscola</para>
        /// </remarks>
        public static double Parse(string value)
        {
            if (value == null)
            {
                throw new ArgumentNullException(
                    "value",
                    "Value cannot be null");
            }

            double result;
            if (ParseCore(value, out result) == false)
            {
                throw new FormatException();
            }

            return result;
        }


        /// <summary>
        /// Parsing di una stringa esteso (riconosce anche la notazione "tecnica"), ma non genera errori all'occorrenza
        /// </summary>
        /// <param name="text">La stringa da analizzare</param>
        /// <param name="result">Il valore risultante dall'interpretazione</param>
        /// <returns>True se l'interpretazione e' riuscita</returns>
        /// <remarks>
        /// <para>Come per il metodo "Parse" della struttura "Double" nativa, se la funzione non riesce ad interpretare il formato, restituisce zero in <paramref name="result"/></para>
        /// </remarks>
        public static bool TryParse(string text, out double value)
        {
            return ParseCore(text, out value);
        }


        /// <summary>
        /// Procedura interna per interpretazione del formato "tecnico"
        /// </summary>
        /// <param name="text">La stringa da analizzare</param>
        /// <param name="result">Il valore risultante dall'interpretazione</param>
        /// <returns>True se l'interpretazione e' riuscita</returns>
        /// <remarks>
        /// <para>Come per il metodo "Parse" della struttura "Double" nativa, se la funzione non riesce ad interpretare il formato, restituisce zero in <paramref name="result"/></para>
        /// </remarks>
        private static bool ParseCore(string text, out double result)
        {
            //in caso di fallimento deve restituire zero
            result = 0;

            //non prosegue se la stringa e' nulla
            if (text == null)
                return false;


            //prova a interpretare secondo i formati standard
            if (double.TryParse(text, out result))
                return true;


            //converte la stringa in un vettore di caratteri
            char[] stream = text.ToCharArray();
            int test;
            int ptr = -1;


            //definisce un "consumatore" di caratteri
            //questa funzione consuma un carattere dello stream, purche' questa appartenga al set indicato
            Func<IEnumerable<char>, int> consume = (charSet) =>
            {
                int ix = ptr + 1;

                if (ix >= stream.Length)
                {
                    //fine dello stream
                    return -1;
                }
                else if (charSet.Contains(stream[ix]))
                {
                    //trovato il carattere corrente nel set indicato
                    ptr = ix;
                    return stream[ix];
                }
                else
                {
                    //il carattere corrente non appartiene al set
                    return 0;
                }
            };


            //definisce set wsp
            var csWsp = new[] { ' ' };

            //definisce set segni
            var csSign = new[] { '+', '-' };

            //definisce set digits
            var csDigit = "0123456789".ToCharArray();

            //definisce set separatori
            var csSep = new[] { '.', ',' };

            //definisce set suffissi
            var csMiniSuffix = "mÂµnpf".ToCharArray();
            var csMaxiSuffix = "kMGTP".ToCharArray();
            var csMicroSuffix = new[] { 'u' };
            var csKiloSuffix = new[] { 'K' };


            //consuma wsp
            while (consume(csWsp) > 0) { };

            //consuma segno
            test = consume(csSign);
            bool isNegative = (test > 0 && (char)test == '-');

            //consuma digits parte intera
            int numInt = 0;

            while ((test = consume(csDigit)) > 0)
            {
                result = result * 10 + (test & 0x0F);
                numInt++;
            }

            //consuma separatore
            if (consume(csSep) > 0)
            {
                //consuma digits parte frazionaria
                double frac = 0;
                int numFrac = 0;

                while ((test = consume(csDigit)) > 0)
                {
                    frac = frac * 10 + (test & 0x0F);
                    numFrac++;
                }

                result += (frac / Math.Pow(10, numFrac));
            }
            else if (numInt == 0)
            {
                //si puo' omettere la parte intera solo se c'e' il separatore decimale
                result = 0;
                return false;
            }

            //cambia segno, se necessario
            if (isNegative)
                result = -result;

            //consuma wsp
            while (consume(csWsp) > 0) { };

            //consuma suffisso
            if ((test = consume(csMiniSuffix)) > 0)
            {
                //suffisso per valori "piccoli"
                int pos = 1 + Array.IndexOf<char>(csMiniSuffix, (char)test);
                result *= Math.Pow(10, -pos * 3);
            }
            else if ((test = consume(csMaxiSuffix)) > 0)
            {
                //suffisso per valori "grandi"
                int pos = 1 + Array.IndexOf<char>(csMaxiSuffix, (char)test);
                result *= Math.Pow(10, pos * 3);
            }
            else if ((test = consume(csMicroSuffix)) > 0)
            {
                //suffisso alternativo per il "micro"
                result *= 1e-6;
            }
            else if ((test = consume(csKiloSuffix)) > 0)
            {
                //suffisso alternativo per il "chilo"
                result *= 1e3;
            }

            //consuma wsp
            while ((test = consume(csWsp)) >= 0)
            {
                if (test == 0)
                {
                    //caratteri estranei dopo la fine del numero
                    result = 0;
                    return false;
                }
            };

            //considera OK
            return true;
        }


        /// <summary>
        /// Vincola una variabile a rientrare in un intervallo predefinito
        /// </summary>
        /// <param name="value">Il valore (intrinsecamente rappresentato dall'istanza ospite)</param>
        /// <param name="min">Il minimo valore che la variabile puo' assumere</param>
        /// <param name="max">Il massimo valore che la variabile puo' assumere</param>
        /// <returns>Il nuovo valore eventualmente saturato in basso o in alto</returns>
        public static Double Constraint(
            this Double value,
            Double min,
            Double max)
        {
            if (value < min)
            {
                return min;
            }
            else if (value > max)
            {
                return max;
            }

            return value;
        }


        /// <summary> 
        /// AreClose - Returns whether or not two doubles are "close".  That is, whether or 
        /// not they are within epsilon of each other.  Note that this epsilon is proportional
        /// to the numbers themselves to that AreClose survives scalar multiplication. 
        /// There are plenty of ways for this to return false even for numbers which
        /// are theoretically identical, so no code calling this should fail to work if this
        /// returns false.  This is important enough to repeat:
        /// NB: NO CODE CALLING THIS FUNCTION SHOULD DEPEND ON ACCURATE RESULTS - this should be 
        /// used for optimizations *only*.
        /// </summary> 
        /// <returns> 
        /// bool - the result of the AreClose comparision.
        /// </returns> 
        /// <param name="value1"> The first double to compare. </param>
        /// <param name="value2"> The second double to compare. </param>
        public static bool AreClose(double value1, double value2)
        {
            //in case they are Infinities (then epsilon check does not work)
            if (value1 == value2) return true;
            // This computes (|value1-value2| / (|value1| + |value2| + 10.0)) < DBL_EPSILON 
            double eps = (Math.Abs(value1) + Math.Abs(value2) + 10.0) * DoubleEpsilon;
            double delta = value1 - value2;
            return (-eps < delta) && (eps > delta);
        }


        /// <summary> 
        /// LessThan - Returns whether or not the first double is less than the second double.
        /// That is, whether or not the first is strictly less than *and* not within epsilon of 
        /// the other number.  Note that this epsilon is proportional to the numbers themselves 
        /// to that AreClose survives scalar multiplication.  Note,
        /// There are plenty of ways for this to return false even for numbers which 
        /// are theoretically identical, so no code calling this should fail to work if this
        /// returns false.  This is important enough to repeat:
        /// NB: NO CODE CALLING THIS FUNCTION SHOULD DEPEND ON ACCURATE RESULTS - this should be
        /// used for optimizations *only*. 
        /// </summary>
        /// <returns> 
        /// bool - the result of the LessThan comparision. 
        /// </returns>
        /// <param name="value1"> The first double to compare. </param> 
        /// <param name="value2"> The second double to compare. </param>
        public static bool LessThan(double value1, double value2)
        {
            return (value1 < value2) && !AreClose(value1, value2);
        }


        /// <summary>
        /// GreaterThan - Returns whether or not the first double is greater than the second double. 
        /// That is, whether or not the first is strictly greater than *and* not within epsilon of
        /// the other number.  Note that this epsilon is proportional to the numbers themselves
        /// to that AreClose survives scalar multiplication.  Note,
        /// There are plenty of ways for this to return false even for numbers which 
        /// are theoretically identical, so no code calling this should fail to work if this
        /// returns false.  This is important enough to repeat: 
        /// NB: NO CODE CALLING THIS FUNCTION SHOULD DEPEND ON ACCURATE RESULTS - this should be 
        /// used for optimizations *only*.
        /// </summary> 
        /// <returns>
        /// bool - the result of the GreaterThan comparision.
        /// </returns>
        /// <param name="value1"> The first double to compare. </param> 
        /// <param name="value2"> The second double to compare. </param>
        public static bool GreaterThan(double value1, double value2)
        {
            return (value1 > value2) && !AreClose(value1, value2);
        }


        /// <summary>
        /// LessThanOrClose - Returns whether or not the first double is less than or close to
        /// the second double.  That is, whether or not the first is strictly less than or within 
        /// epsilon of the other number.  Note that this epsilon is proportional to the numbers
        /// themselves to that AreClose survives scalar multiplication.  Note, 
        /// There are plenty of ways for this to return false even for numbers which 
        /// are theoretically identical, so no code calling this should fail to work if this
        /// returns false.  This is important enough to repeat: 
        /// NB: NO CODE CALLING THIS FUNCTION SHOULD DEPEND ON ACCURATE RESULTS - this should be
        /// used for optimizations *only*.
        /// </summary>
        /// <returns> 
        /// bool - the result of the LessThanOrClose comparision.
        /// </returns> 
        /// <param name="value1"> The first double to compare. </param> 
        /// <param name="value2"> The second double to compare. </param>
        public static bool LessThanOrClose(double value1, double value2)
        {
            return (value1 < value2) || AreClose(value1, value2);
        }


        /// <summary>
        /// GreaterThanOrClose - Returns whether or not the first double is greater than or close to 
        /// the second double.  That is, whether or not the first is strictly greater than or within 
        /// epsilon of the other number.  Note that this epsilon is proportional to the numbers
        /// themselves to that AreClose survives scalar multiplication.  Note, 
        /// There are plenty of ways for this to return false even for numbers which
        /// are theoretically identical, so no code calling this should fail to work if this
        /// returns false.  This is important enough to repeat:
        /// NB: NO CODE CALLING THIS FUNCTION SHOULD DEPEND ON ACCURATE RESULTS - this should be 
        /// used for optimizations *only*.
        /// </summary> 
        /// <returns> 
        /// bool - the result of the GreaterThanOrClose comparision.
        /// </returns> 
        /// <param name="value1"> The first double to compare. </param>
        /// <param name="value2"> The second double to compare. </param>
        public static bool GreaterThanOrClose(double value1, double value2)
        {
            return (value1 > value2) || AreClose(value1, value2);
        }


        /// <summary>
        /// IsOne - Returns whether or not the double is "close" to 1.  Same as AreClose(double, 1), 
        /// but this is faster.
        /// </summary>
        /// <returns>
        /// bool - the result of the AreClose comparision. 
        /// </returns>
        /// <param name="value"> The double to compare to 1. </param> 
        public static bool IsOne(double value)
        {
            return Math.Abs(value - 1.0) < 10.0 * DoubleEpsilon;
        }


        /// <summary>
        /// IsZero - Returns whether or not the double is "close" to 0.  Same as AreClose(double, 0), 
        /// but this is faster.
        /// </summary> 
        /// <returns> 
        /// bool - the result of the AreClose comparision.
        /// </returns> 
        /// <param name="value"> The double to compare to 0. </param>
        public static bool IsZero(double value)
        {
            return Math.Abs(value) < 10.0 * DoubleEpsilon;
        }


        /// <summary> 
        /// 
        /// </summary>
        /// <param name="value"></param> 
        /// <returns></returns>
        public static bool IsBetweenZeroAndOne(double value)
        {
            return (GreaterThanOrClose(value, 0) && LessThanOrClose(value, 1));
        }


#if !PBTCOMPILER
        [StructLayout(LayoutKind.Explicit)]
        private struct NanUnion
        {
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
            /*************************************************************************
             * Soppresso il warning perche' si tratta di simulare una "union",
             * che non e' prassi normale
             *************************************************************************/
            [FieldOffset(0)]
            internal double DoubleValue;

            [FieldOffset(0)]
            internal UInt64 UintValue;
        }



        // The standard CLR double.IsNaN() function is approximately 100 times slower than our own wrapper, 
        // so please make sure to use DoubleUtil.IsNaN() in performance sensitive code.
        // PS item that tracks the CLR improvement is DevDiv Schedule : 26916.
        // IEEE 754 : If the argument is any value in the range 0x7ff0000000000001L through 0x7fffffffffffffffL
        // or in the range 0xfff0000000000001L through 0xffffffffffffffffL, the result will be NaN. 
        public static bool IsNaN(double value)
        {
            NanUnion t = new NanUnion();
            t.DoubleValue = value;

            UInt64 exp = t.UintValue & 0xfff0000000000000;
            UInt64 man = t.UintValue & 0x000fffffffffffff;

            return (exp == 0x7ff0000000000000 || exp == 0xfff0000000000000) && (man != 0);
        }
#endif

    }
}
