﻿using System;
using System.Globalization;


namespace Cet.Develop.Core
{
    public static class Int32Extensions
    {
        /// <summary>
        /// Esegue il test logico del risultato tra il valore ed una maschera
        /// </summary>
        /// <param name="value">Il valore (intrinsecamente rappresentato dall'istanza ospite)</param>
        /// <param name="mask">La maschera usata per il test</param>
        /// <returns>True se il risultato dell'operazione e' non-zero</returns>
        public static bool MaskTest(
            this Int32 value,
            Int32 mask)
        {
            return (value & mask) != 0;
        }


        /// <summary>
        /// Converte un numero in BCD
        /// </summary>
        /// <param name="value">Il valore da convertire</param>
        /// <returns>Il valore in BCD risultato dalla conversione</returns>
        public static int ToBcd(Int32 value)
        {
            return int.Parse(
                value.ToString(CultureInfo.CurrentCulture),
                NumberStyles.AllowHexSpecifier);
        }


        /// <summary>
        /// Converte un numero dal BCD
        /// </summary>
        /// <param name="value">Il valore in BCD da convertire</param>
        /// <returns>Il valore risultante</returns>
        public static int FromBcd(Int32 value)
        {
            return int.Parse(
                value.ToString("X", CultureInfo.CurrentCulture),
                CultureInfo.CurrentCulture);
        }

    }
}
