﻿using System;


namespace Cet.Develop.Core
{
    public static class DateTimeExtensions
    {

        /// <summary>
        /// Restituisce un campo data/ora troncando le frazioni di secondo
        /// </summary>
        /// <param name="timestamp">Il timestamp da troncare</param>
        /// <returns>Il timestamp troncato</returns>
        public static DateTime TruncateToSecond(DateTime timestamp)
        {
            var ticks = timestamp.Ticks % 10000000L;
            return timestamp - TimeSpan.FromTicks(ticks);
        }


        /// <summary>
        /// Ricava il minore tra i due timestamp indicati
        /// </summary>
        /// <param name="date1">Il primo timestamp</param>
        /// <param name="date2">Il secondo timestamp</param>
        /// <returns>Il risultato della funzione</returns>
        public static DateTime Min(
            DateTime date1,
            DateTime date2)
        {
            return (date1 < date2)
                ? date1
                : date2;
        }


        /// <summary>
        /// Ricava il maggiore tra i due timestamp indicati
        /// </summary>
        /// <param name="date1">Il primo timestamp</param>
        /// <param name="date2">Il secondo timestamp</param>
        /// <returns>Il risultato della funzione</returns>
        public static DateTime Max(
            DateTime date1,
            DateTime date2)
        {
            return (date1 > date2)
                ? date1
                : date2;
        }

    }
}
