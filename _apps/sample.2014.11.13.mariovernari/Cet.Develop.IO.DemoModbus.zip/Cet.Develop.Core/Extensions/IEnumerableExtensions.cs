﻿using System;
using System.Collections.Generic;


namespace Cet.Develop.Core
{
    public static class IEnumerableExtensions
    {
        /// <summary>
        /// Fornisce la posizione dell'elemento di una lista alla quale il predicato viene soddisfatto
        /// </summary>
        /// <typeparam name="T">Il tipo di oggetto considerato</typeparam>
        /// <param name="collection">La lista contenente gli oggetti da valutare</param>
        /// <param name="comparer">Il predicato che serve a stabilire quando la ricerca ha avuto seguito</param>
        /// <returns>L'indice alla lista coorispondente all'oggetto che ha soddisfatto il predicato</returns>
        public static int IndexOf<T>(
            this IEnumerable<T> collection,
            Func<T, bool> comparer)
        {
            var index = 0;

            foreach (var item in collection)
            {
                if (comparer(item))
                {
                    return index;
                }

                index++;
            }

            return -1;
        }

    }
}
