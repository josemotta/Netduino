﻿using System;
using System.Xml.Linq;


namespace Cet.Develop.Core
{
    public static class FormatHelpers
    {
        /// <summary>
        /// Conversione del valore indicato nel formato testo ISO-8601
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToStringIso(object value)
        {
            if (value == null)
                return null;

            var xe = new XElement(
                "dummy",
                value);

            return (string)xe;
        }


        /// <summary>
        /// Conversione del testo ISO-8601 indicato nell'equivalente valore
        /// </summary>
        /// <param name="text"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static object FromStringIso(
            string text,
            Type type)
        {
            var xe = new XElement(
                "dummy", 
                text ?? string.Empty);

            if (type == typeof(Boolean))
            {
                return (bool?)xe ?? false;
            }
            else if (type == typeof(Int32))
            {
                return (int?)xe ?? 0;
            }
            else if (type == typeof(Int64))
            {
                return (long?)xe ?? 0L;
            }
            else if (type == typeof(Single))
            {
                return (float?)xe ?? 0f;
            }
            else if (type == typeof(Double))
            {
                return (double?)xe ?? 0d;
            }
            else if (type == typeof(String))
            {
                return (string)xe;
            }
            else if (type == typeof(DateTime))
            {
                return DateTimeSerializationHelper.TryDeserializeTimestamp(text) ?? DateTime.MinValue;
            }
            else if (type == typeof(TimeSpan))
            {
                return (TimeSpan?)xe ?? TimeSpan.Zero;
            }
            else if (type == typeof(Guid))
            {
                return (Guid?)xe ?? Guid.Empty;
            }
            else
            {
                throw new NotSupportedException();
            }
        }


        /// <summary>
        /// Formatta in modo comprensibile un numero che rappresenta una dimensione in bytes
        /// </summary>
        /// <param name="size">La dimensione in bytes</param>
        /// <returns>Una stringa che meglio esprime la dimensione</returns>
        public static string FormatBytes(long size)
        {
            const long KiB = 1024;
            const long MiB = KiB * KiB;
            const long GiB = MiB * KiB;
            const long TiB = GiB * KiB;

            string result;

            if (size >= TiB)
            {
                decimal fraction = decimal.Divide(size, TiB);
                result = string.Format("{0:##.##} TiB", fraction);
            }
            else if (size >= GiB)
            {
                decimal fraction = decimal.Divide(size, GiB);
                result = string.Format("{0:##.##} GiB", fraction);
            }
            else if (size >= MiB)
            {
                decimal fraction = decimal.Divide(size, MiB);
                result = string.Format("{0:##.##} MiB", fraction);
            }
            else if (size >= KiB)
            {
                decimal fraction = decimal.Divide(size, KiB);
                result = string.Format("{0:##.##} KiB", fraction);
            }
            else if (size > 0)
            {
                decimal fraction = size;
                result = string.Format("{0:##.##} Bytes", fraction);
            }
            else
            {
                result = "0 Bytes";
            }

            return result;
        }

    }
}
