﻿using System;


namespace Cet.Develop.Core
{
    public static partial class MathHelpers
    {
        /// <summary>
        /// Restituisce il doppio di pi greco
        /// </summary>
        public static readonly double TwoPI = Math.PI * 2.0;


        /// <summary>
        /// Restituisce la meta' di pi greco
        /// </summary>
        public static readonly double HalfPI = Math.PI * 0.5;


        /// <summary>
        /// Converte un angolo da gradi sessagesimali a radianti
        /// </summary>
        /// <param name="degrees"></param>
        /// <returns></returns>
        public static double DegToRad(double degrees)
        {
            return Math.PI * degrees / 180.0;
        }


        /// <summary>
        /// Converte un angolo da radianti a gradi sessagesimali
        /// </summary>
        /// <param name="radians"></param>
        /// <returns></returns>
        public static double RadToDeg(double radians)
        {
            return 180.0 * radians / Math.PI;
        }



        public static TimeSpan Min(
            TimeSpan val1,
            TimeSpan val2)
        {
            long ticks = Math.Min(
                val1.Ticks,
                val2.Ticks);

            return TimeSpan.FromTicks(ticks);
        }



        public static TimeSpan Max(
            TimeSpan val1,
            TimeSpan val2)
        {
            long ticks = Math.Max(
                val1.Ticks,
                val2.Ticks);

            return TimeSpan.FromTicks(ticks);
        }

    }
}
