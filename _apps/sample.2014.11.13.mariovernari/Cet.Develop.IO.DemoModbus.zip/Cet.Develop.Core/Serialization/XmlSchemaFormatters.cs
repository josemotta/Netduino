﻿using System;
using System.Xml.Linq;


namespace Cet.Develop.Core
{
    public static class XmlSchemaFormatters
    {
        public static string FormatBoolean(Boolean value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatInt32(Int32 value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatInt64(Int64 value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatUInt32(UInt32 value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatUInt64(UInt64 value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatSingle(Single value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatDouble(Double value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatDecimal(Decimal value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatDateTime(DateTime value)
        {
            return DateTimeSerializationHelper.SerializeTimestamp(value);
        }


        public static string FormatTimeSpan(TimeSpan value)
        {
            return (string)new XAttribute("_", value);
        }


        public static string FormatGuid(Guid value)
        {
            return (string)new XAttribute("_", value);
        }

    }
}
