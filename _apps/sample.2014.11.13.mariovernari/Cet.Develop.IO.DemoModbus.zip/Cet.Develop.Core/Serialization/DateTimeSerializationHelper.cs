﻿using System;
using System.Xml;


namespace Cet.Develop.Core
{
    public static class DateTimeSerializationHelper
    {
        /// <summary>
        /// Converte il timestamp specificato in una stringa il cui formato
        /// risulta aderente allo standard ISO 8601
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static string SerializeTimestamp(DateTime timestamp)
        {
            return XmlConvert.ToString(
                timestamp,
                XmlDateTimeSerializationMode.Utc);
        }


        /// <summary>
        /// Converte la stringa specificata in un timestamp. La stringa
        /// si intende aderente allo standard ISO 8601
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static DateTime DeserializeTimestamp(string text)
        {
            return XmlConvert.ToDateTime(
                text,
                XmlDateTimeSerializationMode.Local);
        }


        /// <summary>
        /// Tenta la conversione della stringa in un timestamp
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static DateTime? TryDeserializeTimestamp(string text)
        {
            if (string.IsNullOrEmpty(text))
                return null;

            try
            {
                var timestamp = DateTimeSerializationHelper.DeserializeTimestamp(text);
                return timestamp;
            }
            catch (FormatException)
            {
                return null;
            }
        }

    }
}
