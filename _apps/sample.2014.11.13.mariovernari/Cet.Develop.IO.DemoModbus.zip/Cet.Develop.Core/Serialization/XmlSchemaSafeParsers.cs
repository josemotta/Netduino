﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;


namespace Cet.Develop.Core
{
    public static class XmlSchemaSafeParsers
    {
        public static Boolean? TryParseBoolean(string data)
        {
            try
            {
                return (Boolean?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static Int32? TryParseInt32(string data)
        {
            try
            {
                return (Int32?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static Int64? TryParseInt64(string data)
        {
            try
            {
                return (Int64?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static UInt32? TryParseUInt32(string data)
        {
            try
            {
                return (UInt32?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static UInt64? TryParseUInt64(string data)
        {
            try
            {
                return (UInt64?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static Single? TryParseSingle(string data)
        {
            try
            {
                return (Single?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static Double? TryParseDouble(string data)
        {
            try
            {
                return (Double?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static Decimal? TryParseDecimal(string data)
        {
            try
            {
                return (Decimal?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static DateTime? TryParseDateTime(string data)
        {
            try
            {
                var text = (string)new XAttribute("_", data);
                return DateTimeSerializationHelper.TryDeserializeTimestamp(text);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static TimeSpan? TryParseTimeSpan(string data)
        {
            try
            {
                return (TimeSpan?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }


        public static Guid? TryParseGuid(string data)
        {
            try
            {
                return (Guid?)new XAttribute("_", data);
            }
            catch (FormatException)
            {
                return null;
            }
        }

    }
}
