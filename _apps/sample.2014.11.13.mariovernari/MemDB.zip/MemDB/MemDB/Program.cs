﻿//#define SNIPPET
//#define ORIG
#define ALT

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml.Linq;

namespace MemDB
{
    class MyClass { }

    class Program
    {
#if SNIPPET
        static void Main(string[] args)
        {
            var x = new MyClass();
            var y = new MyClass();

            x = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForFullGCComplete();

            Console.ReadKey();
        }
#endif

#if ORIG
        static bool shutdown;
        static Random rnd = new Random(new object().GetHashCode());

        static TickListener c1, c2, c3;


        static void Main(string[] args)
        {
            var tl = new List<Thread>();

            for (int i = 0; i < 3; i++)
            {
                var t = new Thread(Producer);
                t.Start("P" + i);
            }

            c1 = new TickListener() { Name = "C1" };
            Ticker.Instance.Subscribe(c1);

            Console.WriteLine("Press any key to add another listener...");
            Console.ReadKey();
            Console.WriteLine();

            c2 = new TickListener() { Name = "C2" };
            Ticker.Instance.Subscribe(c2);

            Console.WriteLine("Press any key to remove the first listener...");
            Console.ReadKey();
            Console.WriteLine();

            c1 = null;
            //c1 = new TickListener() { Name = "C4" };
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

            Console.WriteLine("Press any key to add another listener...");
            Console.ReadKey();
            Console.WriteLine();

            c3 = new TickListener() { Name = "C3" };
            Ticker.Instance.Subscribe(c3);

            Console.WriteLine("Press any key to terminate...");
            Console.ReadKey();
            Console.WriteLine();

            Console.WriteLine("Waiting for threads completion...");
            shutdown = true;
            foreach (var t in tl)
            {
                t.Join();
            }

        }
#endif

#if ALT
        static bool shutdown;
        static Random rnd = new Random(new object().GetHashCode());

        static List<TickListener> cl = new List<TickListener>();


        static void Main(string[] args)
        {
            var tl = new List<Thread>();

            for (int i = 0; i < 3; i++)
            {
                var t = new Thread(Producer);
                t.Start("P" + i);
            }

            {
                var c = new TickListener() { Name = "C1" };
                Ticker.Instance.Subscribe(c);
                cl.Add(c);
            }

            Console.WriteLine("Press any key to add another listener...");
            Console.ReadKey();
            Console.WriteLine();

            {
                var c = new TickListener() { Name = "C2" };
                Ticker.Instance.Subscribe(c);
                cl.Add(c);
            }

            Console.WriteLine("Press any key to remove the first listener...");
            Console.ReadKey();
            Console.WriteLine();

            cl.RemoveAt(0);
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

            Console.WriteLine("Press any key to add another listener...");
            Console.ReadKey();
            Console.WriteLine();

            {
                var c = new TickListener() { Name = "C3" };
                Ticker.Instance.Subscribe(c);
                cl.Add(c);
            }

            Console.WriteLine("Press any key to terminate...");
            Console.ReadKey();
            Console.WriteLine();

            Console.WriteLine("Waiting for threads completion...");
            shutdown = true;
            foreach (var t in tl)
            {
                t.Join();
            }

        }
#endif


        static void Producer(object state)
        {
            var key = (string)state;
            int count = 0;

            while (shutdown == false)
            {
                if (--count == 0)
                {
                    Ticker.Instance.Notify(key);
                }
                else if (count < 0)
                {
                    count = 20 + rnd.Next(30);
                }

                Thread.Sleep(100);
            }
        }

    }



    public class TickListener
        : IObserver<TickInfo>
    {
        public string Name;

        public void OnCompleted()
        {
            throw new NotImplementedException();
        }

        public void OnError(Exception error)
        {
            throw new NotImplementedException();
        }

        public void OnNext(TickInfo value)
        {
            var keys = string.Join(",", value.KeyChanged.ToArray());
            Console.WriteLine(
                "{0}: TS={1}; Keys={2}",
                this.Name,
                value.Timestamp,
                keys);
        }
    }


    public class TickInfo
    {
        public TickInfo(
            TimeSpan ts,
            List<string> keys)
        {
            this.Timestamp = ts;
            this.KeyChanged = keys;
        }

        public readonly TimeSpan Timestamp;
        public readonly IEnumerable<string> KeyChanged;
    }


    public sealed class Ticker
        : IObservable<TickInfo>
    {
        #region Singleton pattern

        private Ticker()
        {
            this._initialTimestamp = DateTime.Now;
            this._timer = new Timer(
                this.TimerTick,
                null,
                1000,
                1000);
        }


        private static Ticker _instance;


        public static Ticker Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Ticker();

                return _instance;
            }
        }

        #endregion


        #region Timing

        private Timer _timer;
        private DateTime _initialTimestamp;


        private void TimerTick(object state)
        {
            var keys = new List<string>();
            var now = DateTime.Now;

            foreach (NotificationInfo ni in this._notifiers.Values)
            {
                if (ni.Timespan > ni.LastTick)
                {
                    keys.Add(ni.Key);
                    ni.LastTick = now;
                }
            }

            var info = new TickInfo(
                now - this._initialTimestamp,
                keys);

            var observers = this
                ._subscribers
                .Select(_ => _.GetObserver())
                .Where(_ => _ != null)
                .ToArray(); //importante, perchè invoca il metodo

            for (int i = 0; i < observers.Length; i++)
            {
                var obs = observers[i];
                obs.OnNext(info);
            }
        }

        #endregion


        #region Notification

        private readonly Dictionary<string, NotificationInfo> _notifiers = new Dictionary<string, NotificationInfo>();


        public void Notify(string key)
        {
            NotificationInfo info;

            if (this._notifiers.TryGetValue(key, out info) == false)
            {
                info = new NotificationInfo();
                info.Key = key;
                this._notifiers.Add(key, info);
            }

            info.Timespan = DateTime.Now;
        }


        public void ClearNotifications()
        {
            this._notifiers.Clear();
        }


        private class NotificationInfo
        {
            public string Key;
            public DateTime Timespan;
            public DateTime LastTick;
        }

        #endregion


        #region Subscription

        private readonly List<Subscriber> _subscribers = new List<Subscriber>();


        public IDisposable Subscribe(IObserver<TickInfo> observer)
        {
            var subscr = new Subscriber(
                this._subscribers,
                observer);

            this._subscribers.Add(subscr);
            return subscr;
        }


        private class Subscriber
            : IDisposable
        {
            public Subscriber(
                List<Subscriber> subscribers,
                IObserver<TickInfo> observer)
            {
                this._subscribers = subscribers;
                this._wref = new WeakReference(observer);
            }


            private readonly List<Subscriber> _subscribers;
            private WeakReference _wref;


            public IObserver<TickInfo> GetObserver()
            {
                if (this._wref.IsAlive)
                {
                    return (IObserver<TickInfo>)this._wref.Target;
                }
                else
                {
                    this.Dispose();
                    return null;
                }
            }


            #region IDisposable Members

            private bool _disposed;


            ~Subscriber()
            {
                this.Dispose(false);
            }


            protected virtual void Dispose(bool disposing)
            {
                if (this._disposed == false)
                {
                    if (disposing)
                    {
                        // Disposing from the dispose method.
                    }

                    // Disposing either from dispose or finalize.
                    this._subscribers.Remove(this);

                    this._disposed = true;
                }
            }


            public void Dispose()
            {
                this.Dispose(true);
                GC.SuppressFinalize(this);
            }

            #endregion

        }

        #endregion

    }
}
