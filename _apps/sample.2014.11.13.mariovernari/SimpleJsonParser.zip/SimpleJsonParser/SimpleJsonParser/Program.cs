﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleJsonParser
{

    class Program
    {
        static void Main(string[] args)
        {
            //var s = System.IO.File.ReadAllText(@"..\..\test1.json");

            var s = " [ 1, null, { \"obj\":null , \"tizio\":345 } , true   ] ";

#if true
            JToken jdom = JsonHelpers.Parse(s);

            var jarr = (JArray)jdom;
            jarr.Add((JValue)789);

            var jobj = (JObject)jarr[2];
            jobj["pinco"] = "pallino";
            double v = (double)jobj["tizio"];
            Console.WriteLine(v);

            jobj["q"] = null;
            //jobj.Add("q", 3.14159);   //should throw!

            string jtxt = JsonHelpers.Serialize(jdom);
            Console.WriteLine(jtxt);
#else
            try
            {
                JsonParser.Parse(s);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
#endif
            //Test0();

            Console.WriteLine("Press any key...");
            Console.ReadKey();
        }


        static async void Test0()
        {
            try
            {
                //await Test1();
                await Test2();
            }
            catch (Exception ex)
            {
                Console.WriteLine("caught=" + ex);
            }
        }

        static async Task Test1()
        {
            DoWork1(0);
            await Task.Delay(100);
        }

        static int DoWork1(int arg)
        {
            if (arg == 0)
            {
                throw new ArgumentNullException("arg");
            }
            return arg;
        }


        static async Task Test2()
        {
            //DoWork2(0);
            await DoWork2Async(0);
            await Task.Delay(100);
        }

        static int DoWork2(int arg)
        {
            bool f = true;
            TimerCallback cb = _ =>
            {
                f = true;
                throw new OverflowException();
            };

            using (var tmr = new Timer(cb, null, 500, -1))
            {
                while (f) Thread.Sleep(10);
            }

            return 0;
        }

        static Task<int> DoWork2Async(int arg)
        {
            var tcs = new TaskCompletionSource<int>();

            bool f = true;
            TimerCallback cb = _ =>
            {
                try
                {
                    f = false;
                    throw new OverflowException();
                }
                catch (Exception ex)
                {
                    tcs.SetException(ex);
                }
            };

            using (var tmr = new Timer(cb, null, 500, -1))
            {
                while (f) Thread.Sleep(10);
            }

            tcs.SetResult(0);

            return tcs.Task;
        }

    }
}
