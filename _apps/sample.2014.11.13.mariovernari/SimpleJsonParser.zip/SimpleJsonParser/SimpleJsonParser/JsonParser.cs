﻿using System;
using System.Collections;
using System.Text;

namespace SimpleJsonParser
{
    public static class JsonHelpers
    {
        /// <summary>
        /// Define the whitespace-equivalent characters
        /// </summary>
        private const string WhiteSpace = " \u0009\u000A\u000D";


        /// <summary>
        /// Parse a JSON-string to a specific DOM
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static JToken Parse(string text)
        {
            var rd = new JSonReader(text);
            var ctx = new JsonParserContext(rd)
                .ConsumeWhiteSpace()
                .First(true, JsonHelpers.ConsumeObject, JsonHelpers.ConsumeArray);

            return (JToken)ctx.Result;
        }


        /// <summary>
        /// Serialize the specific DOM to a JSON-string
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string Serialize(JToken source)
        {
            var sb = new StringBuilder();
            source.Serialize(sb);
            return sb.ToString();
        }


        /// <summary>
        /// Consume an arbitrary number of whitespace characters
        /// </summary>
        /// <param name="ctx"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeWhiteSpace(
            this JsonParserContext ctx
            )
        {
            JSonReader src;
            for (int p = (src = ctx.Source).Position, len = src.Text.Length; p < len; p++)
            {
                if (WhiteSpace.IndexOf(src.Text[p]) < 0)
                {
                    src.Position = p;
                    break;
                }
            }

            return ctx;
        }


        /// <summary>
        /// Consume any character (at least one) in the specified set
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="charset"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeAnyChar(
            this JsonParserContext ctx,
            string charset,
            bool throws
            )
        {
            var src = ctx.Source;
            var rtn = new JsonParserContext(src);

            char c;
            if (charset.IndexOf(c = src.Text[src.Position]) >= 0)
            {
                src.Position++;
                rtn.SetResult(c);
            }
            else if (throws)
            {
                throw new JsonParseException("Expected char not found.");
            }

            return rtn;
        }


        /// <summary>
        /// Consume all the characters in the specified sequence
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="sequence"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeAllChars(
            this JsonParserContext ctx,
            string sequence,
            bool throws
            )
        {
            var src = ctx.Source;
            var rtn = new JsonParserContext(src);

            for (int q = 0, p = src.Position; q < sequence.Length; q++, p++)
            {
                if (src.Text[p] != sequence[q])
                {
                    if (throws)
                    {
                        throw new JsonParseException("Expected char not found.");
                    }

                    return rtn;
                }
            }

            src.Position += sequence.Length;
            rtn.SetResult(sequence);
            return rtn;
        }


        /// <summary>
        /// Consume a JSON object
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeObject(
            this JsonParserContext ctx,
            bool throws
            )
        {
            JsonParserContext rtn;
            if ((rtn = ctx.ConsumeWhiteSpace().ConsumeAnyChar("{", throws)).IsSucceeded)
            {
                var jctr = new JObject();
                bool shouldThrow = false;

                do
                {
                    if ((rtn = rtn.ConsumeString(shouldThrow)).IsSucceeded)
                    {
                        var name = (string)(JValue)rtn.Result;
                        rtn = rtn
                            .ConsumeWhiteSpace()
                            .ConsumeAnyChar(":", true)
                            .ConsumeValue(true);

                        jctr.Add(name, (JToken)rtn.Result);
                    }

                    shouldThrow = true;
                }
                while ((char)(rtn = rtn.ConsumeWhiteSpace().ConsumeAnyChar(",}", true)).Result == ',');

                rtn.SetResult(jctr);
            }

            return rtn;
        }


        /// <summary>
        /// Consume a JSON array
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeArray(
            this JsonParserContext ctx,
            bool throws
            )
        {
            JsonParserContext rtn;
            if ((rtn = ctx.ConsumeWhiteSpace().ConsumeAnyChar("[", throws)).IsSucceeded)
            {
                var jctr = new JArray();
                bool shouldThrow = false;

                do
                {
                    if ((rtn = rtn.ConsumeValue(shouldThrow)).IsSucceeded)
                        jctr.Add((JToken)rtn.Result);
                    shouldThrow = true;
                }
                while ((char)(rtn = rtn.ConsumeWhiteSpace().ConsumeAnyChar(",]", true)).Result == ',');

                rtn.SetResult(jctr);
            }

            return rtn;
        }


        /// <summary>
        /// Consume any suitable JSON value token
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeValue(
            this JsonParserContext ctx,
            bool throws
            )
        {
            return ctx.First(
                throws,
                JsonHelpers.ConsumeString,
                JsonHelpers.ConsumeNumber,
                JsonHelpers.ConsumeObject,
                JsonHelpers.ConsumeArray,
                JsonHelpers.ConsumeBoolean,
                JsonHelpers.ConsumeNull
                );
        }


        /// <summary>
        /// Consume a JSON numeric token
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeNumber(
            this JsonParserContext ctx,
            bool throws
            )
        {
            const string Leading = "-0123456789";
            const string Allowed = Leading + ".Ee+";

            var src = ctx.Source;
            JsonParserContext rtn;
            if ((rtn = ctx.ConsumeWhiteSpace().ConsumeAnyChar(Leading, throws)).IsSucceeded)
            {
                var sb = new StringBuilder();
                sb.Append((char)rtn.Result);

                for (int p = src.Position, len = src.Text.Length; p < len; p++)
                {
                    char c;
                    if (Allowed.IndexOf(c = src.Text[p]) < 0)
                    {
                        src.Position = p;
                        break;
                    }
                    else
                    {
                        sb.Append(c);
                    }
                }

                rtn.SetResult(
                    new JValue { BoxedValue = double.Parse(sb.ToString()) }
                    );
            }

            return rtn;
        }


        /// <summary>
        /// Consume a JSON string token
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeString(
            this JsonParserContext ctx,
            bool throws
            )
        {
            var src = ctx.Source;
            JsonParserContext rtn;
            if ((rtn = ctx.ConsumeWhiteSpace().ConsumeAnyChar("\"", throws)).IsSucceeded)
            {
                var sb = new StringBuilder();

                for (int p = src.Position, len = src.Text.Length; p < len; p++)
                {
                    char c;
                    if ((c = src.Text[p]) == '"')
                    {
                        src.Position = p + 1;
                        break;
                    }
                    else
                    {
                        sb.Append(c);
                    }
                }

                rtn.SetResult(
                    new JValue { BoxedValue = sb.ToString() }
                    );
            }

            return rtn;
        }


        /// <summary>
        /// Consume a JSON boolean token
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeBoolean(
            this JsonParserContext ctx,
            bool throws
            )
        {
            JsonParserContext rtn;
            if ((rtn = ctx.ConsumeWhiteSpace().ConsumeAnyChar("ft", throws)).IsSucceeded)
            {
                bool flag = (char)rtn.Result == 't';
                rtn = rtn.ConsumeAllChars(flag ? "rue" : "alse", true);
                rtn.SetResult(
                    new JValue { BoxedValue = flag }
                    );
            }

            return rtn;
        }


        /// <summary>
        /// Consume the JSON "null" token
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        private static JsonParserContext ConsumeNull(
            this JsonParserContext ctx,
            bool throws
            )
        {
            JsonParserContext rtn;
            if ((rtn = ctx.ConsumeWhiteSpace().ConsumeAnyChar("n", throws)).IsSucceeded)
            {
                rtn = rtn.ConsumeAllChars("ull", true);
                rtn.SetResult(
                    new JValue { BoxedValue = null }
                    );
            }

            return rtn;
        }


        /// <summary>
        /// Yield the consumption of the current context to a series of possible parsers
        /// The control will pass to the first one able to manage the source.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <param name="funcs"></param>
        /// <returns></returns>
        private static JsonParserContext First(
            this JsonParserContext ctx,
            bool throws,
            params JsonParseDelegate[] funcs
            )
        {
            for (int i = 0; i < funcs.Length; i++)
            {
                JsonParserContext rtn;
                if ((rtn = funcs[i](ctx, false)).IsSucceeded)
                {
                    return rtn;
                }
            }

            if (throws)
            {
                throw new JsonParseException("Unmatched handler for context.");
            }
            else
            {
                return new JsonParserContext(ctx.Source);
            }
        }


        /// <summary>
        /// Delegate used for the "smart" matching pattern selection
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="throws"></param>
        /// <returns></returns>
        internal delegate JsonParserContext JsonParseDelegate(JsonParserContext ctx, bool throws);

    }


    /// <summary>
    /// Trivial string reader
    /// </summary>
    internal class JSonReader
    {
        public JSonReader(string text)
        {
            this.Text = text;
        }

        public readonly string Text;
        public int Position;

    }


    /// <summary>
    /// Context data used by the parser
    /// </summary>
    internal class JsonParserContext
    {
        public JsonParserContext(JSonReader source)
        {
            this.Source = source;
        }

        public readonly JSonReader Source;
        public bool IsSucceeded { get; private set; }
        public object Result { get; private set; }

        public void SetResult(object result)
        {
            this.Result = result;
            this.IsSucceeded = true;
        }
    }


    /// <summary>
    /// JSON parser specific exception thrown in case of error
    /// </summary>
    public class JsonParseException 
        : Exception
    {
        public JsonParseException(string message)
            : base(message)
        {
        }
    }


    /// <summary>
    /// Abstract base for any elemento of the JSON DOM
    /// </summary>
    public abstract class JToken
    {
        protected JToken() { }
        internal abstract void Serialize(StringBuilder sb);


        #region String conversion operators

        public static implicit operator JToken(string value)
        {
            return new JValue { BoxedValue = value };
        }

        public static implicit operator string(JToken value)
        {
            var jval = value as JValue;

            if (jval != null)
            {
                if (jval.BoxedValue is string == false)
                    throw new ArrayTypeMismatchException();

                return (string)jval.BoxedValue;
            }

            throw new InvalidCastException();
        }

        #endregion


        #region Numeric conversion operator

        public static implicit operator JToken(double value)
        {
            return new JValue { BoxedValue = value };
        }

        public static implicit operator JToken(int value)
        {
            return new JValue { BoxedValue = (double)value };
        }

        public static implicit operator double(JToken value)
        {
            var jval = value as JValue;

            if (jval != null)
            {
                if (jval.BoxedValue is double == false)
                    throw new ArrayTypeMismatchException();

                return (double)jval.BoxedValue;
            }

            throw new InvalidCastException();
        }

        #endregion


        #region Boolean conversion operator

        public static implicit operator JToken(bool value)
        {
            return new JValue { BoxedValue = value };
        }

        public static implicit operator bool(JToken value)
        {
            var jval = value as JValue;

            if (jval != null)
            {
                if (jval.BoxedValue is bool == false)
                    throw new ArrayTypeMismatchException();

                return (bool)jval.BoxedValue;
            }

            throw new InvalidCastException();
        }

        #endregion

    }


    /// <summary>
    /// Represent a valued-node of the JSON DOM
    /// </summary>
    public class JValue 
        : JToken
    {
        internal object BoxedValue;

        internal override void Serialize(StringBuilder sb)
        {
            if (this.BoxedValue == null)
            {
                sb.Append("null");
            }
            else if (this.BoxedValue is bool)
            {
                sb.Append((bool)this.BoxedValue ? "true" : "false");
            }
            else if (this.BoxedValue is double)
            {
                sb.Append(((double)this.BoxedValue).ToString());
            }
            else if (this.BoxedValue is string)
            {
                sb.Append('"');
                sb.Append((string)this.BoxedValue);
                sb.Append('"');
            }
            else
            {
                throw new NotSupportedException();
            }
        }
    }


    /// <summary>
    /// Represent a key-value pair instance used for the JSON object bag
    /// </summary>
    public class JProperty 
        : JToken
    {
        public JProperty(
            string name,
            JToken value
            )
        {
            this.Name = name;
            this.Value = value;
        }


        public readonly string Name;
        public JToken Value;


        internal override void Serialize(StringBuilder sb)
        {
            sb.Append('"');
            sb.Append(this.Name);
            if (this.Value != null)
            {
                sb.Append("\":");
                this.Value.Serialize(sb);
            }
            else
            {
                sb.Append("\":null");
            }
        }

    }


    /// <summary>
    /// Represent a JSON object
    /// </summary>
    public class JObject 
        : JToken, IEnumerable
    {
        private Hashtable _items = new Hashtable();


        /// <summary>
        /// Add a keyed-value to the object's bag
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        /// <remarks>You cannot use a key that is already existent in the bag</remarks>
        public void Add(string name, JToken value)
        {
            var item = (JToken)value;
            this._items.Add(
                name,
                new JProperty(name, item)
                );
        }


        /// <summary>
        /// Get an existent keyed-value from the bag.
        /// When set, the value replaces the existent entry, or is added if not present.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public JToken this[string name]
        {
            get { return ((JProperty)this._items[name]).Value; }
            set 
            {
                if (this._items.ContainsKey(name))
                {
                    ((JProperty)this._items[name]).Value = value;
                }
                else
                {
                    this.Add(name, value);
                }
            }
        }


        /// <summary>
        /// Remove the entry related to the specified name
        /// </summary>
        /// <param name="name"></param>
        public void Remove(string name)
        {
            this._items.Remove(name);
        }


        internal override void Serialize(StringBuilder sb)
        {
            sb.Append('{');
            bool sep = false;

            foreach (string key in this._items.Keys)
            {
                if (sep) sb.Append(',');
                sep = true;

                JProperty item;
                if ((item = (JProperty)this._items[key]) != null)
                {
                    item.Serialize(sb);
                }
                else
                {
                    sb.Append("null");
                }
            }

            sb.Append('}');
        }


        public IEnumerator GetEnumerator()
        {
            return this._items.GetEnumerator();
        }

    }


    /// <summary>
    /// Represent a JSON array
    /// </summary>
    public class JArray 
        : JToken, IEnumerable
    {
        private ArrayList _items = new ArrayList();


        /// <summary>
        /// Add an object at the end of the collection
        /// </summary>
        /// <param name="item"></param>
        public void Add(JToken item)
        {
            this.Insert(
                this._items.Count, 
                item
                );
        }


        /// <summary>
        /// Insert an object at the specified position
        /// </summary>
        /// <param name="position"></param>
        /// <param name="item"></param>
        public void Insert(
            int position, 
            JToken item
            )
        {
            this._items.Insert(
                position, 
                item
                );
        }


        /// <summary>
        /// Get the value stored at the specified position.
        /// When set, the value replaces the existent entry.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public JToken this[int index]
        {
            get { return (JToken)this._items[index]; }
            set { this._items[index] = value; }
        }


        /// <summary>
        /// Remove the entry at the specified position
        /// </summary>
        /// <param name="index"></param>
        public void RemoveAt(int index)
        {
            this._items.RemoveAt(index);
        }


        public IEnumerator GetEnumerator()
        {
            return this._items.GetEnumerator();
        }


        internal override void Serialize(StringBuilder sb)
        {
            sb.Append('[');
            for (int i = 0, count = this._items.Count; i < count; i++)
            {
                if (i > 0) sb.Append(',');

                JToken item;
                if ((item = (JToken)this._items[i]) != null)
                {
                    item.Serialize(sb);
                }
                else
                {
                    sb.Append("null");
                }
            }
            sb.Append(']');
        }

    }
}
