﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModularCommSimulation
{
    delegate Task ExecDelegate(Transaction trans);


    enum DataDirection
    {
        Outgoing,
        Incoming,
    }


    class Transaction
    {
        public Guid SessionId = Guid.NewGuid();
        public Node[] Path;
        public int FromIndex;
        public DataDirection Direction = DataDirection.Outgoing;
        public bool KeepAlive;
        public object DataIn;
        public object DataOut;
    }


    class Node
    {
        public string Id;
        public object Parameters;
    }
}
