﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ModularCommSimulation
{
    class Program
    {
        static void Main(string[] args)
        {
            //handlers subscription
            TransactionManager.Instance.Register("my-serializer", MySerializer.ExecAsync);
            TransactionManager.Instance.Register("my-protocol-codec", MyProtocol.ExecAsync);
            TransactionManager.Instance.Register("comm-master-send", MyComm.ExecMasterAsync);
            TransactionManager.Instance.Register("comm-port-open", MyComm.ExecStartListeningAsync);
            TransactionManager.Instance.Register("comm-port-close", MyComm.ExecStopListeningAsync);

            MainAsync().Wait();

            Console.ReadKey();
        }

        static async Task MainAsync()
        {
            {
                //open the port "COM1" for listening
                var trans = new Transaction();
                trans.Path = new Node[]
                {
                    new Node { Id = "comm-port-open", Parameters = "COM1" },
                };
                await trans.Send();
            }

            //execute a number of operation in parallel
            Parallel.For(
                0,
                10,
                async i =>
                {
                    //simulation of a command to some device, 
                    //which returns the given input as doubled
                    double given = 1234.56789 * i;

                    var trans = new Transaction();
                    trans.Path = new Node[]
                    {
                        new Node { Id = "my-serializer" },
                        new Node { Id = "my-protocol-codec" },
                        new Node { Id = "comm-master-send", Parameters = "COM1" },
                    };
                    trans.DataIn = given;
                    await trans.Send();
                    var returned = (double)trans.DataOut;
                    Console.WriteLine("complete: given={0}; returned={1}", given, returned);
                });

            //wait for an user keypress
            Console.ReadKey();

            {
                //close the comm port
                var trans = new Transaction();
                trans.Path = new Node[]
                {
                    new Node { Id = "comm-port-close", Parameters = "COM1" },
                };
                await trans.Send();
            }
        }
    }


    /**
     * SERIALIZER (and DESERIALIZER)
     * The role of the serializer is to convert the concrete data (application/data layers)
     * to any suitable format allowed for the data-exchange.
     * Ideally, this section should be unaware by the specific protocol,
     * but most of the times isn't so
     **/
    static class MySerializer
    {
        public static async Task ExecAsync(
            Transaction trans
            )
        {
            if (trans.Direction == DataDirection.Outgoing)
            {
                //serialize the given number to a string
                var d = (double)trans.DataIn;
                string s_in = d.ToString();

                //create a derived transaction and forward it to the node-chain
                var t = trans.CreateNext();
                t.DataIn = s_in;
                await t.Send();
                var s_out = (string)t.DataOut;

                //deserialize the string to a number
                trans.DataOut = double.Parse(s_out);
            }
            else if (trans.Direction == DataDirection.Incoming)
            {
                //TODO
            }
        }
    }


    /**
     * PROTOCOL-CODEC
     * The role of the protocol codec is to wrap the serialized data into some "envelope"
     * so that the overall data-exchange can managed reliably over the communication channel.
     * This section also should unwrap the data to be deserialized.
     **/
    static class MyProtocol
    {
        public static async Task ExecAsync(
            Transaction trans
            )
        {
            if (trans.Direction == DataDirection.Outgoing)
            {
                //the request is outgoing, so create a new cookie to hold the status
                var cookie = new MyCookie();
                _session.TryAdd(
                    trans.SessionId,
                    cookie
                    );

                //here's a fake wrapping: just encose the serialized data between square-brackets
                var s_in = (string)trans.DataIn;
                s_in = "[" + s_in + "]";

                //again, forward a new derived-transaction
                var t = trans.CreateNext();
                t.DataIn = s_in;
                await t.Send();

                //take the result off and "unwraps" the deserialized data
                string s_out = cookie.Data;
                s_out = s_out.Trim('[', ']');
                trans.DataOut = s_out;

                //no further need of the cookie: trash it
                _session.TryRemove(trans.SessionId, out cookie);
            }
            else if (trans.Direction == DataDirection.Incoming)
            {
                //the response (or a piece of it) is incoming:
                //retrieve the cookie related to this message
                MyCookie cookie;
                if (_session.TryGetValue(trans.SessionId, out cookie) == false)
                    return;

                //check for the proper "protocol" format (both brackets)
                var answer = (string)trans.DataIn;
                //Console.WriteLine("found=" + answer);     //uncomment for more details

                int bom = answer.IndexOf('[');
                int eom = answer.IndexOf(']');
                bool found = bom >= 0 && eom > bom;
                if (found)
                {
                    //here is the useful data, but nothing more to say on them
                    cookie.Data = answer.Substring(bom, eom - bom + 1);
                }

                //return an indication of success
                trans.DataOut = found;
            }
        }

        //session register
        static ConcurrentDictionary<Guid, MyCookie> _session = new ConcurrentDictionary<Guid, MyCookie>();

        //an arbitrary session-status container
        private class MyCookie
        {
            public string Data = string.Empty;
        }
    }


    /**
     * COMMUNICATION CHANNEL (proxy)
     * This is the ultimate layer before the native/physical: we really can't dig deeper.
     * Since the incoming data is driven by the system, we need some "daemon" as interface.
     * The below code SIMULATES yet mimics a real serial port, harder to share than a socket
     **/
    static class MyComm
    {
        public static async Task ExecMasterAsync(
            Transaction trans
            )
        {
            //the message is outgoing (toward the physical layer)

            //detect which port is involved, then retrieve the related session
            var port_name = (string)trans.GetCurrentNode().Parameters;
            MyCookie cookie;
            _session.TryGetValue(port_name, out cookie);

            //a serial port can be shared, thus let just one thread at once
            //entering in the exclusive area
            await cookie.SemTx1.WaitAsync();

            //mark the session properly, so any further response will match the id
            cookie.AccessingSessionId = trans.SessionId;

            //just simulate the transmission
            var s_in = (string)trans.DataIn;
            Console.WriteLine("comm out enter: " + trans.SessionId);
            Console.WriteLine("comm tx: " + s_in);

            //set up the expected answer, also adding some "noise" before and after!
            cookie.FakeExpectedAnswer = "no*ise" + s_in + "noi?se";

            //wait a valid answer within a certain timeout (should be parametrized)
            await cookie.SemTx2.WaitAsync(2000);

            //release the sessions free for other pending threads
            cookie.AccessingSessionId = Guid.Empty;
            Console.WriteLine("comm out exit:  " + trans.SessionId);
            cookie.SemTx1.Release();
        }


        public static Task ExecStartListeningAsync(
            Transaction trans
            )
        {
            //detect which port is involved, then tries to create a new session
            var port_name = (string)trans.GetCurrentNode().Parameters;
            var cookie = new MyCookie() { PortName = port_name };
            if (_session.TryAdd(port_name, cookie))
            {
                //create then start a long-running thread as the port-listener
                var t = new Thread(Listener);
                t.Start(cookie);
            }

            return Task.FromResult<object>(null);
        }


        public static Task ExecStopListeningAsync(
            Transaction trans
            )
        {
            //detect which port is involved, then retrieve the related session
            var port_name = (string)trans.GetCurrentNode().Parameters;
            MyCookie cookie;
            if (_session.TryGetValue(port_name, out cookie))
            {
                //signal the request to exit to the thread
                cookie.IsShutdownRequest = true;
            }

            return Task.FromResult<object>(null);
        }


        private static void Listener(object state)
        {
            var cookie = (MyCookie)state;
            int len = 0;

            //cycle until someone will signal to exit
            while (cookie.IsShutdownRequest == false)
            {
                Guid sid;
                string answer;

                if ((sid = cookie.AccessingSessionId) == Guid.Empty)
                {
                    //this is the "neutral-state", where there's no master marking
                    //the port as busy. 
                    len = 0;
                }
                else if (string.IsNullOrEmpty(answer = cookie.FakeExpectedAnswer) == false)
                {
                    //this is the "master-state", where a FAKE mechanism simulates
                    //a device response upon a master request
                    if (++len < answer.Length)
                    {
                        //in order to make the data reception more realistic, we'll collect
                        //the expected string one character a time
                        var trans = new Transaction();
                        trans.SessionId = sid;
                        trans.Path = new Node[]
                        {
                            new Node { Id = "my-protocol-codec" },  //this path should be configured: here's hard-coded for simplicity
                        };

                        //compose the respose transaction so that will "climb" the node tree
                        trans.DataIn = answer.Substring(0, len);
                        trans.Direction = DataDirection.Incoming;
                        trans.Send().Wait();

                        if ((bool)trans.DataOut)
                        {
                            //the closest node returned a success flag,
                            //so a signal to the master can be sent as well
                            len = 0;
                            cookie.FakeExpectedAnswer = null;
                            cookie.SemTx2.Release();
                        }
                    }
                }

                Thread.Sleep(30);
            }

            Console.WriteLine("exit listener");
        }


        //session register
        static ConcurrentDictionary<string, MyCookie> _session = new ConcurrentDictionary<string, MyCookie>();

        //an arbitrary session-status container
        private class MyCookie
        {
            public SemaphoreSlim SemTx1 = new SemaphoreSlim(1);
            public SemaphoreSlim SemTx2 = new SemaphoreSlim(0);
            public Guid AccessingSessionId;
            public string PortName;
            public bool IsShutdownRequest;

            public string FakeExpectedAnswer;
        }

        static Random _rnd = new Random(new object().GetHashCode());

    }
}
