﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModularCommSimulation
{
    static class TransactionExtensions
    {
        public static Node GetCurrentNode(
            this Transaction trans
            )
        {
            return trans.Path[trans.FromIndex];
        }


        public static async Task Send(
            this Transaction trans
            )
        {
            var next_id = trans.Path[trans.FromIndex].Id;
            var handler = TransactionManager.Instance[next_id];
            await handler(trans);
        }


        public static Transaction CreateNext(
            this Transaction current
            )
        {
            if (current.Direction != DataDirection.Outgoing)
            {
                throw new Exception();
            }

            var next = new Transaction();
            next.SessionId = current.SessionId;
            next.Path = current.Path;
            next.FromIndex = current.FromIndex + 1;
            next.KeepAlive = current.KeepAlive;
            next.Direction = current.Direction;
            return next;
        }


        public static Transaction CreateBack(
            this Transaction current
            )
        {
            var next = new Transaction();
            next.SessionId = current.SessionId;
            next.Path = current.Path;
            next.FromIndex = current.FromIndex - 1;
            next.KeepAlive = current.KeepAlive;
            next.Direction = DataDirection.Incoming;
            return next;
        }


        public static int IndexOf(
            this Transaction trans,
            string id
            )
        {
            int pos = trans.Path.Length;
            while (--pos >= 0)
            {
                if (trans.Path[pos].Id == id)
                    break;
            }

            return pos;
        }

    }
}
