﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModularCommSimulation
{
    sealed class TransactionManager
    {
        #region Singleton pattern

        private TransactionManager() { }


        private static TransactionManager _instance;


        public static TransactionManager Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new TransactionManager();

                return _instance;
            }
        }

        #endregion


        private readonly Dictionary<string, ExecDelegate> _register = new Dictionary<string, ExecDelegate>();

        public ExecDelegate this[string key]
        {
            get { return _register[key]; }
        }

        public void Register(
            string nodeId,
            ExecDelegate handler
            )
        {
            this._register.Add(nodeId, handler);
        }

    }
}
