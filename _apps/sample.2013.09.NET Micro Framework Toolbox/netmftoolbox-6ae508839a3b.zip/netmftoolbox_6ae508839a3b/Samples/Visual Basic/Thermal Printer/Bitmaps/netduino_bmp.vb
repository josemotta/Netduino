﻿'
' This file is generated at http://www.netmftoolbox.com/tools/img_to_bin/
' Original filename: netduino.bmp
' Orientation:       column-major order
' Bit order:         Most significant bit
' Inverted:          no
' Timestamp:         2012-12-24 17:12:36
'
Namespace Bitmaps

    ''' <summary>
    ''' netduino.bmp bitmap data
    ''' </summary>
    Public Module netduino_bmp

        ''' <summary>Bitmap width</summary>
        Public Width As Integer = 168
        ''' <summary>Bitmap height</summary>
        Public Height As Integer = 40
        ''' <summary>Bitmap data</summary>
        Public Data() As Byte = {&H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H3F, &HFF, &HC0, &H0, &H0, &HFF, &HFF, &HC0, &H0, &H1, &HFF, &HFF, &HC0,
   &H0, &H3, &HFF, &HFF, &HC0, &H0, &H3, &HF0, &H0, &H0, &H0, &H7, &HC0, &H0, &H0, &H0,
   &H7, &H80, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H7,
   &H80, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H7, &HC0, &H0, &H0, &H0, &H7, &HE0,
   &H0, &H0, &H0, &H3, &HFF, &HFF, &H80, &H0, &H3, &HFF, &HFF, &HC0, &H0, &H1, &HFF, &HFF,
   &HC0, &H0, &H0, &HFF, &HFF, &HC0, &H0, &H0, &H1F, &HFF, &HC0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H3F, &HF0, &H0, &H0, &H0, &H7F, &HFC, &H0, &H0,
   &H0, &HFF, &HFE, &H0, &H0, &H1, &HFF, &HFF, &H0, &H0, &H3, &HF8, &H3F, &H80, &H0, &H3,
   &HE1, &HCF, &H80, &H0, &H7, &HC1, &HE7, &HC0, &H0, &H7, &H83, &HE7, &HC0, &H0, &H7, &H83,
   &HC3, &HC0, &H0, &H7, &H87, &HC3, &HC0, &H0, &H7, &H8F, &H83, &HC0, &H0, &H7, &H8F, &H83,
   &HC0, &H0, &H7, &H9F, &H3, &HC0, &H0, &H7, &HDE, &H7, &HC0, &H0, &H7, &HFE, &H7, &HC0,
   &H0, &H3, &HFC, &HF, &H80, &H0, &H3, &HFC, &H3F, &H80, &H0, &H1, &HF8, &HFF, &H0, &H0,
   &H0, &HF8, &HFE, &H0, &H0, &H0, &H70, &HFC, &H0, &H0, &H0, &H0, &HF0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &HFF, &HFF, &HF8, &H0, &H0, &HFF, &HFF,
   &HFE, &H0, &H0, &HFF, &HFF, &HFF, &H0, &H0, &HFF, &HFF, &HFF, &H80, &H0, &HFF, &HFF, &HFF,
   &HC0, &H0, &H7, &H80, &H7, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0,
   &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0,
   &H7, &H80, &H3, &HC0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H3F, &HF0, &H0, &H0, &H0,
   &H7F, &HFC, &H0, &H0, &H0, &HFF, &HFE, &H0, &H0, &H1, &HF8, &H7F, &H0, &H0, &H3, &HE0,
   &HF, &H80, &H0, &H3, &HC0, &H7, &H80, &H0, &H7, &H80, &H7, &H80, &H0, &H7, &H80, &H3,
   &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0,
   &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H3, &H80, &H7, &H80, &H0,
   &H3, &HC0, &HF, &H80, &H0, &H0, &H0, &H1F, &H80, &H7, &HFC, &H3F, &HFF, &H0, &HF, &HFF,
   &HFF, &HFE, &H0, &HF, &HFF, &HFF, &HFC, &H0, &HF, &HFF, &HFF, &HF0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H7, &HFF, &HF8,
   &H0, &H0, &H7, &HFF, &HFE, &H0, &H0, &H7, &HFF, &HFF, &H0, &H0, &H7, &HFF, &HFF, &H0,
   &H0, &H0, &H0, &HF, &H80, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H3, &HC0, &H0,
   &H0, &H0, &H3, &HC0, &H0, &H0, &H0, &H3, &HC0, &H0, &H0, &H0, &H3, &HC0, &H0, &H0,
   &H0, &H3, &HC0, &H0, &H0, &H0, &H7, &HC0, &H0, &H0, &H0, &HF, &H80, &H0, &H0, &H0,
   &H3F, &H80, &H0, &H7, &HFF, &HFF, &H0, &H0, &H7, &HFF, &HFE, &H0, &H0, &H7, &HFF, &HFC,
   &H0, &H0, &H3, &HFF, &HC0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H1, &HC7, &HFF, &HFF, &H80, &H1,
   &HE7, &HFF, &HFF, &HC0, &H3, &HE7, &HFF, &HFF, &HC0, &H1, &HE7, &HFF, &HFF, &HC0, &H0, &HC0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H3F, &HFF, &HC0, &H0, &H0, &HFF, &HFF,
   &HC0, &H0, &H1, &HFF, &HFF, &HC0, &H0, &H3, &HFF, &HFF, &H80, &H0, &H3, &HE0, &H0, &H0,
   &H0, &H7, &HC0, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0,
   &H7, &H80, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H7, &H80, &H0, &H0, &H0, &H7,
   &H80, &H0, &H0, &H0, &H3, &HC0, &H0, &H0, &H0, &H3, &HF0, &H0, &H0, &H0, &H1, &HFF,
   &HFF, &HC0, &H0, &H0, &HFF, &HFF, &HC0, &H0, &H0, &H7F, &HFF, &HC0, &H0, &H0, &HF, &HFF,
   &H80, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H1F, &HF0, &H0,
   &H0, &H0, &H7F, &HFC, &H0, &H0, &H0, &HFF, &HFE, &H0, &H0, &H1, &HFF, &HFF, &H0, &H0,
   &H3, &HF0, &H1F, &H0, &H0, &H3, &HE0, &HF, &H80, &H0, &H7, &HC0, &H7, &H80, &H0, &H7,
   &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H0,
   &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3, &HC0, &H0, &H7, &H80, &H3,
   &HC0, &H0, &H3, &HC0, &H7, &H80, &H0, &H3, &HE0, &HF, &H80, &H0, &H1, &HF8, &H3F, &H0,
   &H0, &H1, &HFF, &HFE, &H0, &H0, &H0, &HFF, &HFC, &H0, &H0, &H0, &H3F, &HF8, &H0, &H0,
   &H0, &HF, &HE0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
   &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0
   }
    End Module
End Namespace
