﻿'
' This file is generated at http://www.netmftoolbox.com/tools/img_to_bin/
' Original filename: lolshield.bmp
' Orientation:       row-major order
' Bit order:         Most significant bit
' Inverted:          no
' Timestamp:         2012-12-30 13:23:00
'
Namespace Bitmaps

    ''' <summary>
    ''' lolshield.bmp bitmap data
    ''' </summary>
    Public Module lolshield_bmp

        ''' <summary>Bitmap width</summary>
        Public Width As Integer = 16
        ''' <summary>Bitmap height</summary>
        Public Height As Integer = 16
        ''' <summary>Bitmap data</summary>
        Public Data() As Byte = {&HFF, &HFC, &H0, &H0, &H89, &H24, &H95, &H0, &H95, &H24, &H95, &H18, &HC9,
         &H80, &H0, &H0, &HFF, &HFC, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
         &H0, &H0, &H0
         }
    End Module
End Namespace
