/*
 * This file is generated at http://www.netmftoolbox.com/tools/img_to_bin/
 * Original filename: lolshield.bmp
 * Orientation:       row-major order
 * Bit order:         Most significant bit
 * Inverted:          no
 * Timestamp:         2012-12-30 13:16:45
 */
namespace Bitmaps
{
    /// <summary>
    /// lolshield.bmp bitmap data
    /// </summary>
    public static class lolshield_bmp
    {
        /// <summary>Bitmap width</summary>
        public static int Width = 16;
        /// <summary>Bitmap height</summary>
        public static int Height = 16;
        /// <summary>Bitmap data</summary>
        public static byte[] Data = { 0xff, 0xfc, 0x00, 0x00, 0x89, 0x24, 0x95, 0x00, 0x95, 0x24, 0x95, 0x18, 
			0xc9, 0x80, 0x00, 0x00, 0xff, 0xfc, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
			0x00, 0x00, 0x00, 0x00
		 };
    }
}
