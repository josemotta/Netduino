This is a compilation of .NET Micro Framework libraries.

If you like to see some more documentation, see http://netmftoolbox.codeplex.com/documentation

The library is maintained by Stefan Thoolen with a lot of thanks from:
- Steven Don for his help with writing Speaker.cs and his C# expertise
- Mario Vernari for his contributions and help with understanding electronics
- Daniel Loughmiller for the 74HC595 bitbang code
- Chris Walker for a lot of guidance and appreciating and spreading these works
- Matt Isenhower and Steve Bulgin for helping with the installer
- The Netduino Community for if they weren't using this, I wouldn't continue expanding this