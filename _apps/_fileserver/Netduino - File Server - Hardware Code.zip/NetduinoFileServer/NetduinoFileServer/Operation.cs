using System;
using Microsoft.SPOT;

namespace NetduinoFileServer
{
    public enum Operation
    {
        List,
        Get,
        Put,
        Delete
    }
}
