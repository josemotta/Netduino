using System;
using Microsoft.SPOT;

namespace NetduinoFileServer
{
    public enum ReturnCode
    {
        Success,
        Failure
    }
}
