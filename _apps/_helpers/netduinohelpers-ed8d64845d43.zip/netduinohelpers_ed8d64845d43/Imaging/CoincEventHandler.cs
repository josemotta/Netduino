namespace netduino.helpers.Imaging {
    public delegate void CoincEventHandler(object sender, CoincEventArgs e);
}
