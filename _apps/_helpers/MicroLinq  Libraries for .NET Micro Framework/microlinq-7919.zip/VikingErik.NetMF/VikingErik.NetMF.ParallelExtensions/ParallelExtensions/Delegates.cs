using System;

namespace VikingErik.NetMF.ParallelExtensions
{
    public delegate void Action(object o);
}
