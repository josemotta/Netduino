﻿/*
 * NetDuino Web Listener by Hari Wiguna, Sep 2010
 * Requires NetduinoPlus
 * 
 * Responds to: http://x.x.x.x/led/1 by turning onboard LED on.
 * http://x.x.x.x/led/0 turns it off.
 * 
 */

using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;

namespace NetduinoPlusListener01
{
    public class Program
    {
        static OutputPort led = new OutputPort(Pins.ONBOARD_LED, false);

        static string receivedStr = "";
        static string responseStr = "";

        public static void Main()
        {
            WebServer webServer = new WebServer();

            while (true)
            {
                int requestLength = webServer.WaitForRequest(new RequestReceivedDelegate(RequestReceived));
                if (requestLength > 0)
                {
                    //-- Build response --
                    responseStr = "HTTP/1.1 200 OK\nContent-Type: text/html\n\n";
                    responseStr += ProcessRequest(receivedStr);
                    
                    // IMPORTANT: SendResponse() sends response AND closes the connection, please call only once per request.
                    webServer.SendResponse(responseStr); 
                    receivedStr = "";
                }
                Thread.Sleep(100);
            }
        }

        private static string ProcessRequest(string receivedStr)
        {
            //-- Parse the first line of the request: "GET /led/1 HTTP/1.1\r" --
            string firstLine = receivedStr.Substring(0,receivedStr.IndexOf('\n'));
            string[] words = firstLine.Split(' ');
            string[] parts = words[1].Split('/');
            string cmd = parts.Length > 1 ? parts[1] : "";
            string param1 = parts.Length > 2 ? parts[2] : "";
            string param2 = parts.Length > 3 ? parts[3] : "";

            //-- Add more commands and param handling here --
            if (cmd == "led" )
            {
                led.Write(param1 == "1");
            }

            //-- Optional string to return to caller --
            return "Command executed at " + DateTime.Now.ToString();
        }

        private static void RequestReceived(object param)
        {
            receivedStr += (string)param;
        }
    }
}