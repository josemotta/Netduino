//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "SecretLabs_NETMF_Hardware.h"
#include "SecretLabs_NETMF_Hardware_SecretLabs_NETMF_Hardware_PWM.h"

using namespace SecretLabs::NETMF::Hardware;

void PWM::PWM_Enable( CLR_RT_HeapBlock* pMngObj, UINT32 param0, HRESULT &hr )
{
}

void PWM::PWM_Disable( CLR_RT_HeapBlock* pMngObj, UINT32 param0, HRESULT &hr )
{
}

void PWM::PWM_SetDutyCycle( CLR_RT_HeapBlock* pMngObj, UINT32 param0, UINT32 param1, HRESULT &hr )
{
}

void PWM::PWM_SetPulse( CLR_RT_HeapBlock* pMngObj, UINT32 param0, UINT32 param1, UINT32 param2, HRESULT &hr )
{
}

