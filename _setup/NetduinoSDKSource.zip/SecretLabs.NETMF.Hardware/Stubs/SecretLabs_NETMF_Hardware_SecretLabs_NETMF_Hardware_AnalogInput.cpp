//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "SecretLabs_NETMF_Hardware.h"
#include "SecretLabs_NETMF_Hardware_SecretLabs_NETMF_Hardware_AnalogInput.h"

using namespace SecretLabs::NETMF::Hardware;

void AnalogInput::ADC_Enable( CLR_RT_HeapBlock* pMngObj, UINT32 param0, HRESULT &hr )
{
}

void AnalogInput::ADC_Disable( CLR_RT_HeapBlock* pMngObj, UINT32 param0, HRESULT &hr )
{
}

UINT32 AnalogInput::ADC_Read( CLR_RT_HeapBlock* pMngObj, UINT32 param0, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

